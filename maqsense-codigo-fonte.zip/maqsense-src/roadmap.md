# Roadmap — PrediTec

- [x] 1. Visual e páginas (início, lista com busca, ficha da máquina com abas)
- [x] 2. Login, cadastro de máquinas, histórico de manutenção, envio de manuais
- [x] 3. Inspeções preditivas (vibração, temperatura, óleo…) com gráficos e alertas
- [x] 4. Sugestões de manuais por IA após a pesquisa
- [x] 5. Painel com máquinas em alerta e manutenções próximas
