import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { MachineForm } from "@/components/MachineForm";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/maquinas/nova")({
  head: () => ({
    meta: [
      { title: "Cadastrar máquina — MaqSense" },
      { name: "description", content: "Cadastre uma nova máquina com suas especificações." },
      { property: "og:title", content: "Cadastrar máquina — MaqSense" },
      { property: "og:description", content: "Cadastro de máquinas." },
    ],
  }),
  component: NewMachine,
});

function NewMachine() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  return (
    <div className="max-w-3xl">
      <p className="label-tech">// Novo equipamento</p>
      <h1 className="mb-6 text-3xl font-bold">Cadastrar máquina</h1>
      <MachineForm
        submitLabel="Salvar máquina"
        onSubmit={async (v) => {
          const { data, error } = await supabase.from("machines").insert(v).select("id").single();
          if (error) return void toast.error("Não foi possível salvar.");
          await qc.invalidateQueries({ queryKey: ["machines"] });
          toast.success("Máquina cadastrada.");
          navigate({ to: "/maquinas/$id", params: { id: data.id } });
        }}
      />
    </div>
  );
}
