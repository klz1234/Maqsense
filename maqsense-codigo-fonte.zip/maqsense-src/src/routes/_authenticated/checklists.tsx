import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { AlertTriangle, FileDown, FileSpreadsheet } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { downloadChecklistReport } from "@/lib/checklist-report";
import { MAINTENANCE_KINDS, filterRecords, allMaintenanceQuery, checklistStats, frequentlyMissed, machinesQuery, comparePeriods, checklistCsv } from "@/lib/machines";

export const Route = createFileRoute("/_authenticated/checklists")({
  head: () => ({
    meta: [
      { title: "Checklists — MaqSense" },
      { name: "description", content: "Taxa de conclusão dos checklists por máquina e tipo de manutenção." },
      { property: "og:title", content: "Checklists — MaqSense" },
      { property: "og:description", content: "Itens de checklist mais esquecidos em cada máquina." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: ({ context }) =>
    Promise.all([
      context.queryClient.ensureQueryData(machinesQuery()),
      context.queryClient.ensureQueryData(allMaintenanceQuery()),
    ]),
  component: ChecklistsDashboard,
});

const pct = (a: number, b: number) => Math.round((a / b) * 100);

function ChecklistsDashboard() {
  const { data: machines } = useSuspenseQuery(machinesQuery());
  const { data: records } = useSuspenseQuery(allMaintenanceQuery());
  const [f, setF] = useState({ from: "", to: "", machineId: "", kind: "" });
  const groups = checklistStats(filterRecords(records, f));
  const names = new Map(machines.map((m) => [m.id, m.name]));
  const br = (d: string) => new Date(d + "T00:00").toLocaleDateString("pt-BR");
  const filterLabel = [
    f.from || f.to ? `período ${f.from ? br(f.from) : "início"} a ${f.to ? br(f.to) : "hoje"}` : "todo o período",
    f.machineId ? names.get(f.machineId) : "todas as máquinas",
    f.kind || "todos os tipos",
  ].join(" · ");
  const sel = "h-9 rounded-sm border bg-background px-2 text-sm";
  const checked = groups.reduce((s, g) => s + g.checked, 0);
  const total = groups.reduce((s, g) => s + g.total, 0);
  const missed = groups.flatMap((g) => g.items.filter(frequentlyMissed).map((i) => ({ ...i, g })));
  const [cmp, setCmp] = useState({ aFrom: "", aTo: "", bFrom: "", bTo: "" });
  const base = { machineId: f.machineId, kind: f.kind };
  const cmpOn = !!(cmp.aFrom || cmp.aTo) && !!(cmp.bFrom || cmp.bTo);
  const rows = cmpOn ? comparePeriods(
    checklistStats(filterRecords(records, { ...base, from: cmp.aFrom, to: cmp.aTo })),
    checklistStats(filterRecords(records, { ...base, from: cmp.bFrom, to: cmp.bTo }))) : [];
  const exportCsv = () => {
    const blob = new Blob(["\uFEFF" + checklistCsv(groups, names)], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = `checklists-${new Date().toLocaleDateString("en-CA")}.csv`;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  };

  return (
    <div className="space-y-8">
      <div>
        <p className="label-tech">Checklists</p>
        <h1 className="text-3xl font-bold">Taxa de conclusão</h1>
      </div>
      <div className="flex flex-wrap items-end gap-3 rounded-sm border bg-card p-4">
        <label className="text-xs text-muted-foreground">De<Input type="date" value={f.from} onChange={(e) => setF({ ...f, from: e.target.value })} /></label>
        <label className="text-xs text-muted-foreground">Até<Input type="date" value={f.to} onChange={(e) => setF({ ...f, to: e.target.value })} /></label>
        <label className="flex flex-col text-xs text-muted-foreground">Máquina
          <select className={sel} value={f.machineId} onChange={(e) => setF({ ...f, machineId: e.target.value })}>
            <option value="">Todas</option>
            {machines.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
          </select></label>
        <label className="flex flex-col text-xs text-muted-foreground">Tipo
          <select className={sel} value={f.kind} onChange={(e) => setF({ ...f, kind: e.target.value })}>
            <option value="">Todos</option>
            {MAINTENANCE_KINDS.map((k) => <option key={k} value={k} className="capitalize">{k}</option>)}
          </select></label>
        <Button variant="ghost" size="sm" onClick={() => setF({ from: "", to: "", machineId: "", kind: "" })}>Limpar</Button>
        <Button size="sm" className="ml-auto" disabled={total === 0}
          onClick={() => downloadChecklistReport(groups, names, filterLabel).catch(() => toast.error("Não foi possível gerar o PDF."))}>
          <FileDown /> Relatório em PDF
        </Button>
        <Button size="sm" variant="outline" disabled={total === 0} onClick={exportCsv}>
          <FileSpreadsheet /> Exportar CSV
        </Button>
      </div>
      <section className="space-y-3 rounded-sm border bg-card p-4">
        <p className="label-tech">Comparar dois períodos</p>
        <p className="text-xs text-muted-foreground">Usa a máquina e o tipo escolhidos acima.</p>
        <div className="flex flex-wrap items-end gap-3">
          <span className="text-sm font-semibold">Período A</span>
          <label className="text-xs text-muted-foreground">De<Input type="date" value={cmp.aFrom} onChange={(e) => setCmp({ ...cmp, aFrom: e.target.value })} /></label>
          <label className="text-xs text-muted-foreground">Até<Input type="date" value={cmp.aTo} onChange={(e) => setCmp({ ...cmp, aTo: e.target.value })} /></label>
          <span className="ml-4 text-sm font-semibold">Período B</span>
          <label className="text-xs text-muted-foreground">De<Input type="date" value={cmp.bFrom} onChange={(e) => setCmp({ ...cmp, bFrom: e.target.value })} /></label>
          <label className="text-xs text-muted-foreground">Até<Input type="date" value={cmp.bTo} onChange={(e) => setCmp({ ...cmp, bTo: e.target.value })} /></label>
        </div>
        {!cmpOn ? <p className="text-sm text-muted-foreground">Escolha as datas dos dois períodos para comparar.</p>
          : rows.length === 0 ? <p className="text-sm text-muted-foreground">Nenhum checklist nesses períodos.</p> : (
          <table className="w-full text-sm">
            <thead className="text-left text-xs text-muted-foreground"><tr><th className="py-1">Máquina</th><th>Tipo</th><th>Período A</th><th>Período B</th><th>Diferença</th></tr></thead>
            <tbody>{rows.map((r) => (
              <tr key={r.machine_id + r.kind} className="border-t">
                <td className="py-1">{names.get(r.machine_id) ?? "Máquina"}</td><td className="capitalize">{r.kind}</td>
                <td className="font-mono-ui">{r.a == null ? "—" : r.a + "%"}</td><td className="font-mono-ui">{r.b == null ? "—" : r.b + "%"}</td>
                <td className={`font-mono-ui ${r.diff == null ? "" : r.diff > 0 ? "text-success" : r.diff < 0 ? "text-destructive" : ""}`}>{r.diff == null ? "—" : (r.diff > 0 ? "+" : "") + r.diff + " pts"}</td>
              </tr>))}</tbody>
          </table>)}
      </section>
      {total === 0 ? (
        <p className="rounded-sm border bg-card p-6 text-sm text-muted-foreground">
          Nenhuma manutenção com checklist nesses filtros. Ajuste os filtros, ou crie um checklist na aba Histórico de uma máquina e conclua uma manutenção.
        </p>
      ) : (
        <>
          <div className="grid gap-4 sm:grid-cols-3">
            <div className="rounded-sm border bg-card p-4"><p className="font-mono-ui text-3xl font-bold">{pct(checked, total)}%</p><p className="text-xs text-muted-foreground">Itens verificados (geral)</p></div>
            <div className="rounded-sm border bg-card p-4"><p className="font-mono-ui text-3xl font-bold">{groups.length}</p><p className="text-xs text-muted-foreground">Combinações máquina × tipo</p></div>
            <div className="rounded-sm border bg-card p-4"><p className="font-mono-ui text-3xl font-bold text-destructive">{missed.length}</p><p className="text-xs text-muted-foreground">Itens frequentemente esquecidos</p></div>
          </div>

          {missed.length > 0 && (
            <section className="rounded-sm border border-destructive/50 bg-card p-4">
              <p className="label-tech mb-2 flex items-center gap-1 text-destructive"><AlertTriangle className="size-4" /> Frequentemente não verificados</p>
              <ul className="space-y-1 text-sm">
                {missed.map((i, k) => (
                  <li key={k}><b>{i.item}</b> — {names.get(i.g.machine_id) ?? "Máquina"} · <span className="capitalize">{i.g.kind}</span> · esquecido em {i.missed} de {i.total} serviços</li>
                ))}
              </ul>
            </section>
          )}

          <section className="grid gap-4 md:grid-cols-2">
            {groups.map((g) => {
              const r = pct(g.checked, g.total);
              return (
                <div key={g.machine_id + g.kind} className="space-y-3 rounded-sm border bg-card p-4">
                  <div className="flex items-baseline justify-between gap-2">
                    <Link to="/maquinas/$id" params={{ id: g.machine_id }} className="font-semibold hover:text-primary">{names.get(g.machine_id) ?? "Máquina"}</Link>
                    <span className="font-mono-ui text-xs uppercase text-muted-foreground">{g.kind}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="h-2 flex-1 rounded-full bg-secondary"><div className={`h-2 rounded-full ${r < 50 ? "bg-destructive" : r < 80 ? "bg-primary" : "bg-success"}`} style={{ width: `${r}%` }} /></div>
                    <span className="font-mono-ui text-sm">{r}%</span>
                  </div>
                  <ul className="space-y-1 text-xs">
                    {g.items.map((i) => (
                      <li key={i.item} className={`flex justify-between ${frequentlyMissed(i) ? "font-semibold text-destructive" : "text-muted-foreground"}`}>
                        <span>{i.item}</span><span className="font-mono-ui">{i.total - i.missed}/{i.total}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </section>
        </>
      )}
    </div>
  );
}
