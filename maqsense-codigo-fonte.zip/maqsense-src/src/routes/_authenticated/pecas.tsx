import { createFileRoute } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Pencil, Trash2, Wrench } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  PART_STATUS, type Part, type PartStatus, allMaintenanceQuery, filterParts, machinesQuery, partsCost, partsQuery,
} from "@/lib/machines";

export const Route = createFileRoute("/_authenticated/pecas")({
  head: () => ({
    meta: [
      { title: "Peças — MaqSense" },
      { name: "description", content: "Registro de peças quebradas e das peças que precisam ser compradas." },
      { property: "og:title", content: "Peças — MaqSense" },
      { property: "og:description", content: "Controle de peças quebradas, compras e custos." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: ({ context }) =>
    Promise.all([
      context.queryClient.ensureQueryData(machinesQuery()),
      context.queryClient.ensureQueryData(partsQuery()),
      context.queryClient.ensureQueryData(allMaintenanceQuery()),
    ]),
  component: PartsPage,
});

const empty = {
  name: "", quantity: "1", machine_id: "", status: "quebrada" as PartStatus, notes: "",
  supplier: "", unit_price: "", purchased_at: "", maintenance_id: "",
};
const STATUSES = Object.keys(PART_STATUS) as PartStatus[];
const brl = (n: number) => n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const br = (d: string) => new Date(d.slice(0, 10) + "T00:00").toLocaleDateString("pt-BR");

function PartsPage() {
  const qc = useQueryClient();
  const { data: machines } = useSuspenseQuery(machinesQuery());
  const { data: parts } = useSuspenseQuery(partsQuery());
  const { data: records } = useSuspenseQuery(allMaintenanceQuery());
  const [form, setForm] = useState(empty);
  const [editing, setEditing] = useState<string | null>(null);
  const [f, setF] = useState({ term: "", machineId: "", status: "", from: "", to: "" });
  const names = new Map(machines.map((m) => [m.id, m.name]));
  const recById = new Map(records.map((r) => [r.id, r]));
  const sel = "h-9 rounded-sm border bg-background px-2 text-sm";
  const refresh = () => qc.invalidateQueries({ queryKey: partsQuery().queryKey });
  const machineRecords = records
    .filter((r) => !form.machine_id || r.machine_id === form.machine_id)
    .sort((a, b) => b.performed_at.localeCompare(a.performed_at));

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    const rec = form.maintenance_id ? recById.get(form.maintenance_id) : undefined;
    const row = {
      name: form.name.trim(), quantity: Math.max(1, Number(form.quantity) || 1),
      machine_id: form.machine_id || rec?.machine_id || null, status: form.status, notes: form.notes,
      supplier: form.supplier.trim(), unit_price: form.unit_price === "" ? null : Number(form.unit_price.replace(",", ".")),
      purchased_at: form.purchased_at || null, maintenance_id: form.maintenance_id || null,
    };
    const { error } = editing
      ? await supabase.from("parts").update(row).eq("id", editing)
      : await supabase.from("parts").insert(row);
    if (error) { toast.error("Não foi possível salvar a peça."); return; }
    toast.success(editing ? "Peça atualizada." : "Peça registrada.");
    setForm(empty); setEditing(null); refresh();
  };
  const edit = (p: Part) => {
    setEditing(p.id);
    setForm({
      name: p.name, quantity: String(p.quantity), machine_id: p.machine_id ?? "", status: p.status as PartStatus,
      notes: p.notes, supplier: p.supplier, unit_price: p.unit_price == null ? "" : String(p.unit_price),
      purchased_at: p.purchased_at ?? "", maintenance_id: p.maintenance_id ?? "",
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const setStatus = async (id: string, status: PartStatus) => {
    const { error } = await supabase.from("parts").update({ status }).eq("id", id);
    if (error) toast.error("Não foi possível atualizar."); else refresh();
  };
  const remove = async (id: string) => {
    const { error } = await supabase.from("parts").delete().eq("id", id);
    if (error) toast.error("Não foi possível excluir."); else refresh();
  };

  const shown = filterParts(parts, f);
  const count = (s: PartStatus) => shown.filter((p) => p.status === s).reduce((n, p) => n + p.quantity, 0);
  const toBuy = shown.filter((p) => p.status === "comprar");
  const bought = shown.filter((p) => p.status === "comprada");

  return (
    <div className="space-y-8">
      <div>
        <p className="label-tech">Peças</p>
        <h1 className="text-3xl font-bold">Peças quebradas e compras</h1>
      </div>

      <div className="grid gap-4 sm:grid-cols-5">
        {STATUSES.map((s) => (
          <button key={s} onClick={() => setF({ ...f, status: f.status === s ? "" : s })}
            className={`rounded-sm border bg-card p-4 text-left ${f.status === s ? "border-primary" : ""}`}>
            <p className={`font-mono-ui text-3xl font-bold ${PART_STATUS[s].cls}`}>{count(s)}</p>
            <p className="text-xs text-muted-foreground">{PART_STATUS[s].label}</p>
          </button>
        ))}
        <div className="rounded-sm border bg-card p-4"><p className="font-mono-ui text-xl font-bold text-primary">{brl(partsCost(toBuy))}</p><p className="text-xs text-muted-foreground">Custo previsto (a comprar)</p></div>
        <div className="rounded-sm border bg-card p-4"><p className="font-mono-ui text-xl font-bold">{brl(partsCost(bought))}</p><p className="text-xs text-muted-foreground">Gasto com compradas</p></div>
      </div>

      <form onSubmit={save} className="flex flex-wrap items-end gap-3 rounded-sm border bg-card p-4">
        <p className="label-tech basis-full">{editing ? "Editar peça" : "Registrar peça"}</p>
        <label className="min-w-48 flex-1 text-xs text-muted-foreground">Peça<Input required value={form.name} placeholder="Ex.: Rolamento 6205" onChange={(e) => setForm({ ...form, name: e.target.value })} /></label>
        <label className="w-20 text-xs text-muted-foreground">Qtd.<Input type="number" min={1} value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} /></label>
        <label className="flex flex-col text-xs text-muted-foreground">Máquina
          <select className={sel} value={form.machine_id} onChange={(e) => setForm({ ...form, machine_id: e.target.value, maintenance_id: "" })}>
            <option value="">Nenhuma</option>
            {machines.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
          </select></label>
        <label className="flex flex-col text-xs text-muted-foreground">Situação
          <select className={sel} value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value as PartStatus })}>
            {STATUSES.map((s) => <option key={s} value={s}>{PART_STATUS[s].label}</option>)}
          </select></label>
        <label className="min-w-40 flex-1 text-xs text-muted-foreground">Fornecedor<Input value={form.supplier} placeholder="Ex.: SKF Distribuidora" onChange={(e) => setForm({ ...form, supplier: e.target.value })} /></label>
        <label className="w-32 text-xs text-muted-foreground">Preço unitário (R$)<Input inputMode="decimal" value={form.unit_price} placeholder="0,00" onChange={(e) => setForm({ ...form, unit_price: e.target.value })} /></label>
        <label className="text-xs text-muted-foreground">Data da compra<Input type="date" value={form.purchased_at} onChange={(e) => setForm({ ...form, purchased_at: e.target.value })} /></label>
        <label className="flex flex-col text-xs text-muted-foreground">Substituída na manutenção
          <select className={`${sel} max-w-72`} value={form.maintenance_id} onChange={(e) => setForm({ ...form, maintenance_id: e.target.value })}>
            <option value="">Nenhuma</option>
            {machineRecords.map((r) => (
              <option key={r.id} value={r.id}>{br(r.performed_at)} · {r.kind}{form.machine_id ? "" : ` · ${names.get(r.machine_id) ?? "Máquina"}`}{r.description ? ` · ${r.description.slice(0, 30)}` : ""}</option>
            ))}
          </select></label>
        <label className="basis-full text-xs text-muted-foreground">Observações<Input value={form.notes} placeholder="Ex.: motivo da quebra" onChange={(e) => setForm({ ...form, notes: e.target.value })} /></label>
        <Button type="submit">{editing ? "Salvar alterações" : "Registrar peça"}</Button>
        {editing && <Button type="button" variant="ghost" onClick={() => { setEditing(null); setForm(empty); }}>Cancelar</Button>}
      </form>

      <div className="flex flex-wrap items-end gap-3 rounded-sm border bg-card p-4">
        <label className="min-w-48 flex-1 text-xs text-muted-foreground">Buscar<Input value={f.term} placeholder="Nome, fornecedor ou observação" onChange={(e) => setF({ ...f, term: e.target.value })} /></label>
        <label className="flex flex-col text-xs text-muted-foreground">Máquina
          <select className={sel} value={f.machineId} onChange={(e) => setF({ ...f, machineId: e.target.value })}>
            <option value="">Todas</option>
            {machines.map((m) => <option key={m.id} value={m.id}>{m.name}</option>)}
          </select></label>
        <label className="flex flex-col text-xs text-muted-foreground">Situação
          <select className={sel} value={f.status} onChange={(e) => setF({ ...f, status: e.target.value })}>
            <option value="">Todas</option>
            {STATUSES.map((s) => <option key={s} value={s}>{PART_STATUS[s].label}</option>)}
          </select></label>
        <label className="text-xs text-muted-foreground">Registrada de<Input type="date" value={f.from} onChange={(e) => setF({ ...f, from: e.target.value })} /></label>
        <label className="text-xs text-muted-foreground">Até<Input type="date" value={f.to} onChange={(e) => setF({ ...f, to: e.target.value })} /></label>
        <Button variant="ghost" size="sm" onClick={() => setF({ term: "", machineId: "", status: "", from: "", to: "" })}>Limpar</Button>
      </div>

      {shown.length === 0 ? (
        <p className="rounded-sm border bg-card p-6 text-sm text-muted-foreground">
          {parts.length ? "Nenhuma peça encontrada com esses filtros." : "Nenhuma peça registrada."}
        </p>
      ) : (
        <ul className="divide-y rounded-sm border bg-card">
          {shown.map((p) => {
            const rec = p.maintenance_id ? recById.get(p.maintenance_id) : undefined;
            const price = p.unit_price == null ? null : Number(p.unit_price);
            return (
              <li key={p.id} className="flex flex-wrap items-center gap-3 p-4">
                <div className="min-w-0 flex-1 space-y-0.5">
                  <p className="font-semibold">{p.quantity}× {p.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {p.machine_id ? names.get(p.machine_id) ?? "Máquina" : "Sem máquina"} · registrada em {br(p.created_at)}
                    {p.supplier ? ` · ${p.supplier}` : ""}
                    {price != null ? ` · ${brl(price)} un. (total ${brl(price * p.quantity)})` : ""}
                    {p.purchased_at ? ` · comprada em ${br(p.purchased_at)}` : ""}
                    {p.notes ? ` · ${p.notes}` : ""}
                  </p>
                  {rec && (
                    <p className="flex items-center gap-1 text-xs text-success">
                      <Wrench className="size-3" /> Substituída na manutenção {rec.kind} de {br(rec.performed_at)}{rec.technician ? ` · ${rec.technician}` : ""}
                    </p>
                  )}
                </div>
                <select className={`${sel} ${PART_STATUS[p.status as PartStatus]?.cls ?? ""}`} value={p.status} onChange={(e) => setStatus(p.id, e.target.value as PartStatus)}>
                  {STATUSES.map((s) => <option key={s} value={s}>{PART_STATUS[s].label}</option>)}
                </select>
                <Button size="icon" variant="ghost" aria-label="Editar peça" onClick={() => edit(p)}><Pencil /></Button>
                <Button size="icon" variant="ghost" aria-label="Excluir peça" onClick={() => remove(p.id)}><Trash2 /></Button>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}
