import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { AlertTriangle, CalendarClock, Cpu } from "lucide-react";
import { StatusBadge } from "@/components/StatusBadge";
import {
  allInspectionsQuery,
  daysUntil,
  machinesQuery,
  suggestedStatus,
  upcomingMaintenance,
  type StatusKey,
} from "@/lib/machines";

export const Route = createFileRoute("/_authenticated/painel")({
  head: () => ({
    meta: [
      { title: "Painel — MaqSense" },
      { name: "description", content: "Máquinas em alerta e manutenções próximas." },
      { property: "og:title", content: "Painel — MaqSense" },
      { property: "og:description", content: "Visão geral das máquinas em alerta e das manutenções próximas." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  loader: ({ context }) =>
    Promise.all([
      context.queryClient.ensureQueryData(machinesQuery()),
      context.queryClient.ensureQueryData(allInspectionsQuery()),
    ]),
  component: Dashboard,
});

const rank: Record<StatusKey, number> = { ok: 0, atencao: 1, critico: 2 };

function Dashboard() {
  const { data: machines } = useSuspenseQuery(machinesQuery());
  const { data: inspections } = useSuspenseQuery(allInspectionsQuery());
  const today = new Date().toLocaleDateString("en-CA");

  const alerts = machines
    .map((m) => {
      const fromReadings = suggestedStatus(inspections.filter((i) => i.machine_id === m.id));
      const set = (m.status in rank ? m.status : "ok") as StatusKey;
      const level = rank[fromReadings] > rank[set] ? fromReadings : set;
      return { m, level, byReading: rank[fromReadings] > 0 };
    })
    .filter((x) => x.level !== "ok")
    .sort((a, b) => rank[b.level] - rank[a.level]);

  const upcoming = upcomingMaintenance(machines, today);

  const stats = [
    { label: "Máquinas", value: machines.length, icon: Cpu },
    { label: "Em alerta", value: alerts.length, icon: AlertTriangle },
    { label: "Manutenções em 30 dias", value: upcoming.length, icon: CalendarClock },
  ];

  return (
    <div className="space-y-8">
      <div>
        <p className="label-tech">Visão geral</p>
        <h1 className="text-3xl font-bold">Painel</h1>
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        {stats.map((s) => (
          <div key={s.label} className="rounded-sm border bg-card p-5">
            <s.icon className="size-4 text-primary" />
            <p className="mt-3 font-mono-ui text-3xl font-bold">{s.value}</p>
            <p className="text-sm text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <section className="rounded-sm border bg-card">
          <p className="border-b p-4 label-tech">Máquinas em alerta</p>
          {alerts.length === 0 && <p className="p-4 text-sm text-muted-foreground">Nenhuma máquina em alerta.</p>}
          {alerts.map(({ m, level, byReading }) => (
            <Link key={m.id} to="/maquinas/$id" params={{ id: m.id }} className="flex items-center justify-between gap-3 border-b p-4 last:border-b-0 hover:bg-secondary/50">
              <div>
                <p className="text-sm font-medium">{m.name}</p>
                <p className="text-xs text-muted-foreground">{m.location || "Local não informado"}{byReading && " · pela última inspeção"}</p>
              </div>
              <StatusBadge status={level} />
            </Link>
          ))}
        </section>
        <section className="rounded-sm border bg-card">
          <p className="border-b p-4 label-tech">Manutenções próximas</p>
          {upcoming.length === 0 && (
            <p className="p-4 text-sm text-muted-foreground">Nada nos próximos 30 dias. Defina a "Próxima manutenção" ao editar uma máquina.</p>
          )}
          {upcoming.map((m) => {
            const d = daysUntil(m.next_maintenance_at!, today);
            return (
              <Link key={m.id} to="/maquinas/$id" params={{ id: m.id }} className="flex items-center justify-between gap-3 border-b p-4 last:border-b-0 hover:bg-secondary/50">
                <div>
                  <p className="text-sm font-medium">{m.name}</p>
                  <p className="text-xs text-muted-foreground">{new Date(m.next_maintenance_at! + "T00:00").toLocaleDateString("pt-BR")}</p>
                </div>
                <span className={`font-mono-ui text-xs ${d < 0 ? "text-destructive" : d <= 7 ? "text-primary" : "text-muted-foreground"}`}>
                  {d < 0 ? `${-d} dia(s) atrasada` : d === 0 ? "hoje" : `em ${d} dia(s)`}
                </span>
              </Link>
            );
          })}
        </section>
      </div>
    </div>
  );
}
