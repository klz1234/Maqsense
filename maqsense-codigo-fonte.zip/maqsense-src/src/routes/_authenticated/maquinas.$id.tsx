import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { ArrowLeft, ExternalLink, FileText, Pencil, Trash2, Upload } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { StatusBadge } from "@/components/StatusBadge";
import { MachineForm } from "@/components/MachineForm";
import { InspectionsTab } from "@/components/InspectionsTab";
import { CompleteMaintenanceDialog } from "@/components/CompleteMaintenanceDialog";
import { ChecklistTemplatesEditor } from "@/components/ChecklistTemplatesEditor";
import { MaintenancePhotos } from "@/components/MaintenancePhotos";
import { downloadMaintenanceReport } from "@/lib/maintenance-report";
import { parseChecklist, parsePhotos, checklistTemplatesQuery, uploadMaintenancePhotos } from "@/lib/machines";
import { supabase } from "@/integrations/supabase/client";
import { useServerFn } from "@tanstack/react-start";
import { Sparkles } from "lucide-react";
import { suggestManuals, type ManualSuggestion } from "@/lib/manual-ai.functions";

function AiSuggestions({ machineId }: { machineId: string }) {
  const run = useServerFn(suggestManuals);
  const [items, setItems] = useState<ManualSuggestion[] | null>(null);
  const [busy, setBusy] = useState(false);
  async function go() {
    setBusy(true);
    try {
      const r = await run({ data: { machineId } });
      setItems(r.suggestions);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Falha ao gerar sugestões.");
    } finally {
      setBusy(false);
    }
  }
  return (
    <div className="rounded-sm border bg-card p-4">
      <div className="flex items-center justify-between gap-2">
        <p className="label-tech">Sugestões da IA</p>
        <Button size="sm" variant="outline" onClick={go} disabled={busy}>
          <Sparkles /> {busy ? "Pensando…" : items ? "Gerar de novo" : "Sugerir manuais"}
        </Button>
      </div>
      {!items && !busy && <p className="mt-2 text-sm text-muted-foreground">A IA indica quais documentos do fabricante procurar para esta máquina.</p>}
      {items?.length === 0 && <p className="mt-2 text-sm text-muted-foreground">Nenhuma sugestão.</p>}
      <div className="mt-3 space-y-2">
        {items?.map((s, i) => (
          <div key={i} className="rounded-sm border p-3">
            <div className="flex items-start justify-between gap-2">
              <div>
                <p className="text-sm font-medium">{s.title}</p>
                <p className="mt-0.5 text-xs text-muted-foreground"><span className="mr-1 font-mono-ui uppercase text-primary">{s.kind}</span>{s.why}</p>
              </div>
              <Button asChild size="sm" variant="secondary">
                <a href={`https://www.google.com/search?q=${encodeURIComponent(s.query)}`} target="_blank" rel="noreferrer">Buscar <ExternalLink /></a>
              </Button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
import {
  MAINTENANCE_KINDS,
  inspectionsQuery,
  machineQuery,
  maintenanceQuery,
  manualSearchLinks,
  manualsQuery,
  parseSpecs,
  totalDowntime,
  type Machine,
} from "@/lib/machines";
import { MaintenancePlanCard } from "@/components/MaintenancePlanCard";

export const Route = createFileRoute("/_authenticated/maquinas/$id")({
  head: () => ({
    meta: [
      { title: "Detalhes da máquina — MaqSense" },
      { name: "description", content: "Especificações, histórico de manutenção e manuais do equipamento." },
      { property: "og:title", content: "Detalhes da máquina — MaqSense" },
      { property: "og:description", content: "Ficha técnica do equipamento." },
    ],
  }),
  loader: async ({ context, params }) => {
    const m = await context.queryClient.ensureQueryData(machineQuery(params.id));
    if (!m) throw notFound();
    await Promise.all([
      context.queryClient.ensureQueryData(maintenanceQuery(params.id)),
      context.queryClient.ensureQueryData(checklistTemplatesQuery()),
      context.queryClient.ensureQueryData(manualsQuery(params.id)),
      context.queryClient.ensureQueryData(inspectionsQuery(params.id)),
    ]);
  },
  notFoundComponent: () => (
    <div className="text-center">
      <p className="text-lg font-semibold">Máquina não encontrada.</p>
      <Link to="/maquinas" className="text-primary">Voltar à lista</Link>
    </div>
  ),
  component: MachineDetail,
});

function MachineDetail() {
  const { id } = Route.useParams();
  const { data: m } = useSuspenseQuery(machineQuery(id));
  const qc = useQueryClient();
  const navigate = useNavigate();
  const [editing, setEditing] = useState(false);
  if (!m) return null;

  async function remove() {
    if (!confirm("Excluir esta máquina e todo o seu histórico?")) return;
    const { error } = await supabase.from("machines").delete().eq("id", id);
    if (error) return void toast.error("Não foi possível excluir.");
    await qc.invalidateQueries({ queryKey: ["machines"] });
    navigate({ to: "/maquinas" });
  }

  return (
    <div>
      <Link to="/maquinas" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-4" /> Máquinas
      </Link>
      <div className="mt-3 flex flex-wrap items-start justify-between gap-4">
        <div>
          <p className="label-tech">{m.category || "Equipamento"} · {m.serial_number || "s/ série"}</p>
          <h1 className="text-3xl font-bold">{m.name}</h1>
          <p className="mt-1 text-muted-foreground">
            {[m.manufacturer, m.model].filter(Boolean).join(" · ") || "Fabricante não informado"}
            {m.location && ` — ${m.location}`}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <StatusBadge status={m.status} />
          <Button variant="outline" size="sm" onClick={() => setEditing((e) => !e)}><Pencil /> {editing ? "Cancelar" : "Editar"}</Button>
          <Button variant="ghost" size="icon" aria-label="Excluir" onClick={remove}><Trash2 /></Button>
        </div>
      </div>

      {editing ? (
        <div className="mt-6 max-w-3xl">
          <MachineForm
            initial={m}
            submitLabel="Salvar alterações"
            onSubmit={async (v) => {
              const { error } = await supabase.from("machines").update({ ...v, updated_at: new Date().toISOString() }).eq("id", id);
              if (error) return void toast.error("Não foi possível salvar.");
              await qc.invalidateQueries({ queryKey: ["machine", id] });
              await qc.invalidateQueries({ queryKey: ["machines"] });
              setEditing(false);
              toast.success("Alterações salvas.");
            }}
          />
        </div>
      ) : (
        <Tabs defaultValue="manuais" className="mt-6">
          <TabsList>
            <TabsTrigger value="manuais">Manuais</TabsTrigger>
            <TabsTrigger value="specs">Especificações</TabsTrigger>
            <TabsTrigger value="historico">Histórico</TabsTrigger>
            <TabsTrigger value="inspecoes">Inspeções</TabsTrigger>
          </TabsList>
          <TabsContent value="manuais"><ManualsTab machine={m} /></TabsContent>
          <TabsContent value="specs"><SpecsTab machine={m} /></TabsContent>
          <TabsContent value="historico"><HistoryTab machineId={id} /></TabsContent>
          <TabsContent value="inspecoes"><InspectionsTab machine={m} /></TabsContent>
        </Tabs>
      )}
    </div>
  );
}

function SpecsTab({ machine }: { machine: Machine }) {
  const specs = parseSpecs(machine.specs);
  const base = [
    { label: "Fabricante", value: machine.manufacturer },
    { label: "Modelo", value: machine.model },
    { label: "Nº de série", value: machine.serial_number },
    { label: "Instalação", value: machine.installed_at ? new Date(machine.installed_at + "T00:00").toLocaleDateString("pt-BR") : "" },
  ];
  return (
    <div className="grid gap-6 md:grid-cols-2">
      {[{ t: "Dados gerais", rows: base }, { t: "Parâmetros técnicos", rows: specs }].map((g) => (
        <div key={g.t} className="rounded-sm border bg-card">
          <p className="border-b p-4 label-tech">{g.t}</p>
          {g.rows.length === 0 && <p className="p-4 text-sm text-muted-foreground">Nenhum parâmetro cadastrado.</p>}
          {g.rows.map((r, i) => (
            <div key={i} className="flex justify-between border-b p-4 text-sm last:border-b-0">
              <span className="text-muted-foreground">{r.label}</span>
              <span className="font-mono-ui">{r.value || "—"}</span>
            </div>
          ))}
        </div>
      ))}
      {machine.notes && <p className="rounded-sm border bg-card p-4 text-sm md:col-span-2">{machine.notes}</p>}
    </div>
  );
}

function HistoryTab({ machineId }: { machineId: string }) {
  const { data: machine } = useSuspenseQuery(machineQuery(machineId));
  const { data: records } = useSuspenseQuery(maintenanceQuery(machineId));
  const qc = useQueryClient();
  const [form, setForm] = useState({ performed_at: new Date().toISOString().slice(0, 10), kind: "preventiva", technician: "", description: "", parts_used: "", cost: "", downtime: "" });
  const [before, setBefore] = useState<File[]>([]);
  const [after, setAfter] = useState<File[]>([]);
  const downtime = totalDowntime(records);
  const withDowntime = records.filter((r) => r.downtime_hours != null).length;

  async function add(e: React.FormEvent) {
    e.preventDefault();
    const { downtime: dt, ...rest } = form;
    const { data: rec, error } = await supabase.from("maintenance_records").insert({
      machine_id: machineId, ...rest, cost: form.cost ? Number(form.cost) : null,
      downtime_hours: dt ? Number(dt) : null,
    }).select("id").single();
    if (rec && (before.length || after.length)) {
      const photos = await uploadMaintenancePhotos(machineId, rec.id, [
        ...before.map((file) => ({ file, phase: "antes" as const })),
        ...after.map((file) => ({ file, phase: "depois" as const })),
      ]);
      await supabase.from("maintenance_records").update({ photos }).eq("id", rec.id);
      setBefore([]); setAfter([]); (e.target as HTMLFormElement).reset();
    }
    if (error) return void toast.error("Não foi possível registrar.");
    setForm((f) => ({ ...f, technician: "", description: "", parts_used: "", cost: "", downtime: "" }));
    qc.invalidateQueries({ queryKey: ["maintenance", machineId] });
    toast.success("Manutenção registrada.");
  }

  async function del(rid: string) {
    await supabase.from("maintenance_records").delete().eq("id", rid);
    qc.invalidateQueries({ queryKey: ["maintenance", machineId] });
  }

  return (
    <div className="grid gap-6 md:grid-cols-[1fr_320px]">
      <div className="space-y-6">
        {machine && machine.next_maintenance_at && !machine.next_maintenance_done && (
          <div className="flex items-center justify-between gap-4 rounded-sm border border-primary/40 bg-card p-4">
            <div>
              <p className="label-tech">Próxima manutenção · {new Date(machine.next_maintenance_at + "T00:00").toLocaleDateString("pt-BR")}</p>
              <p className="text-sm">{machine.next_maintenance_task || "Manutenção não descrita"}
                {machine.maintenance_interval_days ? <span className="text-muted-foreground"> · a cada {machine.maintenance_interval_days} dias</span> : null}</p>
            </div>
            <CompleteMaintenanceDialog machine={machine}><Button size="sm">Concluir</Button></CompleteMaintenanceDialog>
          </div>
        )}
        {withDowntime > 0 && (
          <div className="flex gap-6 rounded-sm border bg-card p-4">
            <div><p className="font-mono-ui text-2xl font-bold">{downtime.toLocaleString("pt-BR")} h</p><p className="text-xs text-muted-foreground">Tempo parado total</p></div>
            <div><p className="font-mono-ui text-2xl font-bold">{(downtime / withDowntime).toLocaleString("pt-BR", { maximumFractionDigits: 1 })} h</p><p className="text-xs text-muted-foreground">Média por manutenção</p></div>
          </div>
        )}
      <div className="rounded-sm border bg-card">
        {records.length === 0 && <p className="p-6 text-sm text-muted-foreground">Nenhuma manutenção registrada.</p>}
        {records.map((r) => (
          <div key={r.id} className="flex gap-4 border-b p-4 last:border-b-0">
            <div className="w-24 shrink-0 font-mono-ui text-xs text-muted-foreground">
              {new Date(r.performed_at + "T00:00").toLocaleDateString("pt-BR")}
            </div>
            <div className="flex-1">
              <p className="text-sm"><span className="mr-2 rounded-sm bg-secondary px-1.5 py-0.5 font-mono-ui text-xs uppercase">{r.kind}</span>{r.description || "Sem descrição"}</p>
              <p className="mt-1 text-xs text-muted-foreground">
                {r.technician || "Técnico não informado"}
                {r.cost != null && ` · R$ ${Number(r.cost).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`}
                {r.downtime_hours != null && ` · ${Number(r.downtime_hours).toLocaleString("pt-BR")} h parada`}
              </p>
              {r.parts_used && <p className="mt-1 text-xs"><span className="label-tech mr-1">Peças:</span>{r.parts_used}</p>}
              {parseChecklist(r.checklist).length > 0 && (
                <ul className="mt-1 text-xs">
                  {parseChecklist(r.checklist).map((c, i) => (
                    <li key={i} className={c.checked ? "" : "text-muted-foreground line-through"}>{c.checked ? "✓" : "✗"} {c.item}</li>
                  ))}
                </ul>
              )}
              <MaintenancePhotos photos={parsePhotos(r.photos)} />
            </div>
            {machine && (
              <Button variant="ghost" size="icon" aria-label="Baixar relatório em PDF" title="Relatório em PDF"
                onClick={() => downloadMaintenanceReport(machine, r).catch(() => toast.error("Não foi possível gerar o PDF."))}><FileText /></Button>
            )}
            <Button variant="ghost" size="icon" aria-label="Excluir registro" onClick={() => del(r.id)}><Trash2 /></Button>
          </div>
        ))}
      </div>
        <MaintenancePlanCard machineId={machineId} />
        <ChecklistTemplatesEditor />
      </div>
      <form onSubmit={add} className="h-fit space-y-3 rounded-sm border bg-card p-4">
        <p className="label-tech">Registrar manutenção</p>
        <Input type="date" required value={form.performed_at} onChange={(e) => setForm({ ...form, performed_at: e.target.value })} />
        <div className="flex gap-1 rounded-sm border p-1">
          {MAINTENANCE_KINDS.map((k) => (
            <button type="button" key={k} onClick={() => setForm({ ...form, kind: k })}
              className={`flex-1 rounded-sm px-2 py-1 text-xs capitalize ${form.kind === k ? "bg-secondary" : "text-muted-foreground"}`}>{k}</button>
          ))}
        </div>
        <Input placeholder="Técnico" value={form.technician} onChange={(e) => setForm({ ...form, technician: e.target.value })} />
        <Textarea placeholder="O que foi feito?" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
        <Input placeholder="Peças utilizadas" value={form.parts_used} onChange={(e) => setForm({ ...form, parts_used: e.target.value })} />
        <Input type="number" step="0.01" placeholder="Custo (R$)" value={form.cost} onChange={(e) => setForm({ ...form, cost: e.target.value })} />
        <Input type="number" step="0.1" min="0" placeholder="Tempo parado (horas)" value={form.downtime} onChange={(e) => setForm({ ...form, downtime: e.target.value })} />
        <label className="block text-xs text-muted-foreground">Fotos antes
          <Input type="file" accept="image/*" multiple onChange={(e) => setBefore([...(e.target.files ?? [])])} /></label>
        <label className="block text-xs text-muted-foreground">Fotos depois
          <Input type="file" accept="image/*" multiple onChange={(e) => setAfter([...(e.target.files ?? [])])} /></label>
        <Button type="submit" className="w-full">Registrar</Button>
      </form>
    </div>
  );
}

function ManualsTab({ machine }: { machine: Machine }) {
  const { data: manuals } = useSuspenseQuery(manualsQuery(machine.id));
  const qc = useQueryClient();
  const [title, setTitle] = useState("");
  const [url, setUrl] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [busy, setBusy] = useState(false);
  const links = manualSearchLinks(machine);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    if (!file && !url) return void toast.error("Envie um PDF ou informe um link.");
    setBusy(true);
    let file_path: string | null = null;
    if (file) {
      const { data: u } = await supabase.auth.getUser();
      file_path = `${u.user!.id}/${machine.id}/${Date.now()}-${file.name.replace(/[^\w.-]/g, "_")}`;
      const { error } = await supabase.storage.from("manuals").upload(file_path, file);
      if (error) { setBusy(false); return void toast.error("Falha no envio do arquivo."); }
    }
    const { error } = await supabase.from("manuals").insert({
      machine_id: machine.id, title: title || file?.name || "Manual", url: url || null, file_path,
    });
    setBusy(false);
    if (error) return void toast.error("Não foi possível salvar o manual.");
    setTitle(""); setUrl(""); setFile(null);
    qc.invalidateQueries({ queryKey: ["manuals", machine.id] });
    toast.success("Manual adicionado.");
  }

  async function open(path: string) {
    const { data, error } = await supabase.storage.from("manuals").createSignedUrl(path, 300);
    if (error) return void toast.error("Não foi possível abrir.");
    window.open(data.signedUrl, "_blank", "noopener");
  }

  async function del(mid: string, path: string | null) {
    if (path) await supabase.storage.from("manuals").remove([path]);
    await supabase.from("manuals").delete().eq("id", mid);
    qc.invalidateQueries({ queryKey: ["manuals", machine.id] });
  }

  return (
    <div className="grid gap-6 md:grid-cols-[1fr_320px]">
      <div className="space-y-6">
        <div className="rounded-sm border bg-card">
          <p className="border-b p-4 label-tech">Manuais salvos</p>
          {manuals.length === 0 && <p className="p-4 text-sm text-muted-foreground">Nenhum manual salvo para esta máquina.</p>}
          {manuals.map((d) => (
            <div key={d.id} className="flex items-center gap-3 border-b p-4 last:border-b-0">
              <FileText className="size-4 text-primary" />
              <span className="flex-1 text-sm">{d.title}</span>
              {d.file_path && <Button variant="outline" size="sm" onClick={() => open(d.file_path!)}>Abrir PDF</Button>}
              {d.url && <Button asChild variant="outline" size="sm"><a href={d.url} target="_blank" rel="noreferrer">Link <ExternalLink /></a></Button>}
              <Button variant="ghost" size="icon" aria-label="Remover manual" onClick={() => del(d.id, d.file_path)}><Trash2 /></Button>
            </div>
          ))}
        </div>
        <div className="rounded-sm border bg-card p-4">
          <p className="label-tech">Buscar manual do fabricante</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Pesquisa para <span className="text-foreground">{[machine.manufacturer, machine.model || machine.name].filter(Boolean).join(" ")}</span>
          </p>
          <div className="mt-3 flex flex-wrap gap-2">
            {links.map((l) => (
              <Button key={l.label} asChild variant="secondary" size="sm">
                <a href={l.href} target="_blank" rel="noreferrer">{l.label} <ExternalLink /></a>
              </Button>
            ))}
          </div>
        </div>
        <AiSuggestions machineId={machine.id} />
      </div>
      <form onSubmit={add} className="space-y-3 rounded-sm border bg-card p-4">
        <p className="label-tech">Adicionar manual</p>
        <Input placeholder="Título" value={title} onChange={(e) => setTitle(e.target.value)} />
        <div className="space-y-1.5">
          <Label htmlFor="pdf" className="flex items-center gap-2 text-sm"><Upload className="size-4" /> Arquivo PDF</Label>
          <Input id="pdf" type="file" accept="application/pdf" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
        </div>
        <Input type="url" placeholder="ou link (https://…)" value={url} onChange={(e) => setUrl(e.target.value)} />
        <Button type="submit" className="w-full" disabled={busy}>Salvar manual</Button>
      </form>
    </div>
  );
}
