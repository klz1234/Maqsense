import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { Plus, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { StatusBadge } from "@/components/StatusBadge";
import { machinesQuery, matchesSearch, STATUS } from "@/lib/machines";

export const Route = createFileRoute("/_authenticated/maquinas/")({
  head: () => ({
    meta: [
      { title: "Máquinas — MaqSense" },
      { name: "description", content: "Pesquise e filtre suas máquinas cadastradas." },
      { property: "og:title", content: "Máquinas — MaqSense" },
      { property: "og:description", content: "Pesquisa de máquinas cadastradas." },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(machinesQuery()),
  component: MachinesPage,
});

function MachinesPage() {
  const { data: machines } = useSuspenseQuery(machinesQuery());
  const [term, setTerm] = useState("");
  const [status, setStatus] = useState<string>("todos");

  const filtered = useMemo(
    () => machines.filter((m) => matchesSearch(m, term) && (status === "todos" || m.status === status)),
    [machines, term, status],
  );

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="label-tech">// Inventário</p>
          <h1 className="text-3xl font-bold">Máquinas</h1>
        </div>
        <Button asChild>
          <Link to="/maquinas/nova"><Plus /> Cadastrar máquina</Link>
        </Button>
      </div>

      <div className="mt-6 flex flex-wrap gap-3">
        <div className="relative min-w-64 flex-1">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            className="pl-9"
            placeholder="Pesquisar por nome, fabricante, modelo, série ou local…"
            value={term}
            onChange={(e) => setTerm(e.target.value)}
          />
        </div>
        <div className="flex gap-1 rounded-sm border p-1">
          {["todos", ...Object.keys(STATUS)].map((s) => (
            <button
              key={s}
              onClick={() => setStatus(s)}
              className={`rounded-sm px-3 py-1 text-sm ${status === s ? "bg-secondary text-foreground" : "text-muted-foreground"}`}
            >
              {s === "todos" ? "Todos" : STATUS[s as keyof typeof STATUS].label}
            </button>
          ))}
        </div>
      </div>

      <p className="mt-4 label-tech">{filtered.length} resultado(s)</p>

      {machines.length === 0 ? (
        <div className="mt-4 rounded-sm border border-dashed bg-card p-12 text-center">
          <p className="font-semibold">Nenhuma máquina cadastrada ainda.</p>
          <p className="mt-1 text-sm text-muted-foreground">Comece cadastrando o primeiro equipamento.</p>
          <Button asChild className="mt-4"><Link to="/maquinas/nova">Cadastrar máquina</Link></Button>
        </div>
      ) : (
        <div className="mt-3 overflow-hidden rounded-sm border bg-card">
          {filtered.map((m) => (
            <Link
              key={m.id}
              to="/maquinas/$id"
              params={{ id: m.id }}
              className="grid grid-cols-[1fr_auto] items-center gap-4 border-b p-4 last:border-b-0 hover:bg-accent md:grid-cols-[2fr_1.5fr_1fr_auto]"
            >
              <div>
                <p className="font-semibold">{m.name}</p>
                <p className="font-mono-ui text-xs text-muted-foreground">{m.serial_number || "sem nº de série"}</p>
              </div>
              <p className="hidden text-sm md:block">{[m.manufacturer, m.model].filter(Boolean).join(" · ") || "—"}</p>
              <p className="hidden text-sm text-muted-foreground md:block">{m.location || "—"}</p>
              <StatusBadge status={m.status} />
            </Link>
          ))}
          {filtered.length === 0 && <p className="p-8 text-center text-muted-foreground">Nada encontrado para essa pesquisa.</p>}
        </div>
      )}
    </div>
  );
}
