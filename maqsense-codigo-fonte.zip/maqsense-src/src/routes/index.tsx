import { createFileRoute, Link } from "@tanstack/react-router";
import { ClipboardList, FileText, Search, Settings2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Logo } from "@/components/AppHeader";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MaqSense — Inspeções e manutenção preditiva" },
      { name: "description", content: "Cadastre máquinas, consulte especificações, registre manutenções e encontre manuais dos fabricantes." },
      { property: "og:title", content: "MaqSense — Inspeções e manutenção preditiva" },
      { property: "og:description", content: "Cadastro e pesquisa de máquinas, histórico de manutenção e manuais." },
    ],
  }),
  component: Index,
});

const features = [
  { icon: Search, title: "Pesquisa de máquinas", text: "Busque por nome, fabricante, modelo, série ou local." },
  { icon: Settings2, title: "Especificações", text: "Potência, rotação, tensão — campos livres por equipamento." },
  { icon: ClipboardList, title: "Histórico", text: "Manutenções preventivas, corretivas e preditivas." },
  { icon: FileText, title: "Manuais", text: "Aparecem ao abrir o equipamento pesquisado." },
];

function Index() {
  return (
    <div className="min-h-screen bg-blueprint">
      <header className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
        <Logo />
        <Button asChild size="sm">
          <Link to="/maquinas">Entrar</Link>
        </Button>
      </header>
      <section className="mx-auto max-w-6xl px-4 pb-20 pt-16">
        <p className="label-tech">// Manutenção preditiva · projeto de estudo</p>
        <h1 className="mt-4 max-w-3xl text-5xl font-extrabold leading-[1.05] tracking-tight md:text-6xl">
          Cada máquina, seu histórico e seu manual <span className="text-primary">em um só lugar.</span>
        </h1>
        <p className="mt-6 max-w-xl text-lg text-muted-foreground">
          Cadastre equipamentos, registre inspeções e manutenções e encontre a documentação do fabricante na hora da pesquisa.
        </p>
        <div className="mt-8 flex gap-3">
          <Button asChild size="lg">
            <Link to="/maquinas">Abrir painel</Link>
          </Button>
          <Button asChild size="lg" variant="outline">
            <Link to="/auth">Criar conta</Link>
          </Button>
        </div>
        <div className="mt-20 grid gap-px overflow-hidden rounded-sm border bg-border md:grid-cols-4">
          {features.map((f, i) => (
            <div key={f.title} className="bg-card p-6">
              <div className="flex items-center justify-between">
                <f.icon className="size-5 text-primary" />
                <span className="font-mono-ui text-xs text-muted-foreground">0{i + 1}</span>
              </div>
              <h3 className="mt-6 font-semibold">{f.title}</h3>
              <p className="mt-1 text-sm text-muted-foreground">{f.text}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
