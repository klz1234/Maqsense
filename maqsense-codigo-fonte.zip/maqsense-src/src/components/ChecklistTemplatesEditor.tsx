import { useState } from "react";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { Plus, X } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { MAINTENANCE_KINDS, checklistTemplatesQuery, templateItems } from "@/lib/machines";

export function ChecklistTemplatesEditor() {
  const { data: ts } = useSuspenseQuery(checklistTemplatesQuery());
  const qc = useQueryClient();
  const [kind, setKind] = useState<string>("preventiva");
  const items = templateItems(ts, kind);
  const [text, setText] = useState("");

  async function save(next: string[]) {
    const { error } = await supabase.from("checklist_templates").upsert({ kind, items: next, updated_at: new Date().toISOString() }, { onConflict: "user_id,kind" });
    if (error) return void toast.error("Não foi possível salvar o checklist.");
    qc.invalidateQueries({ queryKey: ["checklist-templates"] });
  }

  return (
    <div className="space-y-3 rounded-sm border bg-card p-4">
      <p className="label-tech">Checklists por tipo de manutenção</p>
      <div className="flex gap-1 rounded-sm border p-1">
        {MAINTENANCE_KINDS.map((k) => (
          <button type="button" key={k} onClick={() => setKind(k)}
            className={`flex-1 rounded-sm px-2 py-1 text-xs capitalize ${kind === k ? "bg-secondary" : "text-muted-foreground"}`}>{k}</button>
        ))}
      </div>
      {items.length === 0 && <p className="text-xs text-muted-foreground">Nenhum item ainda para {kind}.</p>}
      {items.map((it, i) => (
        <div key={i} className="flex items-center justify-between gap-2 text-sm">
          <span>{it}</span>
          <Button variant="ghost" size="icon" aria-label="Remover item" onClick={() => save(items.filter((_, j) => j !== i))}><X /></Button>
        </div>
      ))}
      <form className="flex gap-2" onSubmit={(e) => { e.preventDefault(); if (text.trim()) { save([...items, text.trim()]); setText(""); } }}>
        <Input placeholder="Novo item (ex.: Verificar nível de óleo)" value={text} onChange={(e) => setText(e.target.value)} />
        <Button type="submit" size="icon" variant="outline" aria-label="Adicionar item"><Plus /></Button>
      </form>
      <p className="text-xs text-muted-foreground">Vale para todas as máquinas. Aparece ao concluir uma manutenção desse tipo.</p>
    </div>
  );
}
