import { useEffect, useRef } from "react";
import { Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { CompleteMaintenanceDialog } from "@/components/CompleteMaintenanceDialog";
import { Bell, Check } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { NOTICE_DAYS, daysUntil, dueSoon, machinesQuery } from "@/lib/machines";

export function MaintenanceBell() {
  const { data: machines = [], isSuccess } = useQuery(machinesQuery());
  const today = new Date().toLocaleDateString("en-CA");
  const due = dueSoon(machines, today);
  const shown = useRef("");

  // Pop-up notice whenever the set of due machines changes (e.g. after saving a date).
  useEffect(() => {
    if (!isSuccess) return;
    const key = due.map((m) => m.id + m.next_maintenance_at).join("|");
    if (!key || key === shown.current) return;
    shown.current = key;
    toast.warning(`${due.length} manutenção(ões) em até ${NOTICE_DAYS} dias`, {
      description: due.map((m) => `${m.name}: ${m.next_maintenance_task || "manutenção não descrita"}`).join(" · "),
      duration: 8000,
    });
  }, [isSuccess, due]);

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="icon" aria-label="Avisos de manutenção" className="relative">
          <Bell />
          {due.length > 0 && (
            <span className="absolute -right-0.5 -top-0.5 grid size-4 place-items-center rounded-full bg-primary font-mono-ui text-[10px] text-primary-foreground">
              {due.length}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-0">
        <p className="border-b p-3 label-tech">Manutenções em até {NOTICE_DAYS} dias</p>
        {due.length === 0 && (
          <p className="p-3 text-sm text-muted-foreground">
            Nenhum prazo próximo. Para receber avisos, edite a máquina e preencha "Próxima manutenção".
          </p>
        )}
        {due.map((m) => {
          const d = daysUntil(m.next_maintenance_at!, today);
          return (
            <div key={m.id} className="border-b last:border-b-0">
              <Link to="/maquinas/$id" params={{ id: m.id }} className="flex justify-between gap-2 p-3 pb-1 text-sm hover:bg-secondary/50">
                <span>
                  {m.name}
                  <span className="block text-xs text-muted-foreground">{m.next_maintenance_task || "Manutenção não descrita"}</span>
                </span>
                <span className={`font-mono-ui text-xs ${d < 0 ? "text-destructive" : "text-primary"}`}>
                  {d < 0 ? `${-d} dia(s) atrasada` : d === 0 ? "hoje" : `em ${d} dia(s)`}
                </span>
              </Link>
              <CompleteMaintenanceDialog machine={m}>
                <Button variant="ghost" size="sm" className="mx-2 mb-2 h-7 text-xs">
                  <Check /> Marcar como feita
                </Button>
              </CompleteMaintenanceDialog>
            </div>
          );
        })}
      </PopoverContent>
    </Popover>
  );
}
