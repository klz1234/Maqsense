import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { MaintenancePhoto } from "@/lib/machines";

export function MaintenancePhotos({ photos }: { photos: MaintenancePhoto[] }) {
  const [urls, setUrls] = useState<Record<string, string>>({});
  useEffect(() => {
    if (!photos.length) return;
    supabase.storage.from("maintenance-photos").createSignedUrls(photos.map((p) => p.path), 3600).then(({ data }) => {
      const m: Record<string, string> = {};
      data?.forEach((d) => { if (d.signedUrl && d.path) m[d.path] = d.signedUrl; });
      setUrls(m);
    });
  }, [photos.map((p) => p.path).join()]);
  if (!photos.length) return null;
  return (
    <div className="mt-2 flex flex-wrap gap-4">
      {(["antes", "depois"] as const).map((ph) => {
        const ps = photos.filter((p) => p.phase === ph);
        return ps.length ? (
          <div key={ph}>
            <p className="label-tech mb-1">{ph}</p>
            <div className="flex gap-1">
              {ps.map((p) => urls[p.path] ? (
                <a key={p.path} href={urls[p.path]} target="_blank" rel="noreferrer">
                  <img src={urls[p.path]} alt={`Foto ${ph}`} className="size-16 rounded-sm border object-cover" />
                </a>
              ) : <div key={p.path} className="size-16 rounded-sm border bg-secondary" />)}
            </div>
          </div>
        ) : null;
      })}
    </div>
  );
}
