import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { toast } from "sonner";
import { Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { planMaintenance, type MaintenancePlan } from "@/lib/plan-ai.functions";

export function MaintenancePlanCard({ machineId }: { machineId: string }) {
  const run = useServerFn(planMaintenance);
  const [plan, setPlan] = useState<MaintenancePlan | null>(null);
  const [done, setDone] = useState<Set<number>>(new Set());
  const [busy, setBusy] = useState(false);

  async function go() {
    setBusy(true);
    try {
      setPlan(await run({ data: { machineId } }));
      setDone(new Set());
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Falha ao gerar o plano.");
    } finally {
      setBusy(false);
    }
  }

  const total = plan?.steps.reduce((s, x) => s + x.minutes, 0) ?? 0;

  return (
    <div className="rounded-sm border bg-card p-4">
      <div className="flex items-center justify-between gap-2">
        <p className="label-tech">Plano rápido da IA</p>
        <Button size="sm" variant="outline" onClick={go} disabled={busy}>
          <Sparkles /> {busy ? "Montando…" : plan ? "Gerar de novo" : "Gerar checklist"}
        </Button>
      </div>
      {!plan && !busy && (
        <p className="mt-2 text-sm text-muted-foreground">
          Passo a passo, peças para separar antes e dicas para a máquina ficar menos tempo parada.
        </p>
      )}
      {plan && (
        <div className="mt-4 space-y-5">
          <div>
            <p className="mb-2 text-sm font-medium">Separar antes da parada</p>
            <ul className="space-y-1 text-sm">
              {plan.parts.map((p, i) => (
                <li key={i} className="flex justify-between border-b pb-1 last:border-b-0">
                  <span>{p.name}</span><span className="font-mono-ui text-xs text-muted-foreground">{p.qty}</span>
                </li>
              ))}
            </ul>
            {plan.tools.length > 0 && (
              <p className="mt-2 text-xs text-muted-foreground">Ferramentas: {plan.tools.join(", ")}</p>
            )}
          </div>
          <div>
            <p className="mb-2 text-sm font-medium">
              Checklist <span className="font-mono-ui text-xs text-muted-foreground">≈ {total} min · {done.size}/{plan.steps.length}</span>
            </p>
            <div className="space-y-1">
              {plan.steps.map((s, i) => (
                <label key={i} className="flex cursor-pointer gap-2 rounded-sm p-2 text-sm hover:bg-secondary/50">
                  <input type="checkbox" className="mt-1 accent-primary" checked={done.has(i)}
                    onChange={() => setDone((d) => { const n = new Set(d); n.has(i) ? n.delete(i) : n.add(i); return n; })} />
                  <span className={done.has(i) ? "text-muted-foreground line-through" : ""}>
                    <span className="font-medium">{s.title}</span> <span className="font-mono-ui text-xs text-primary">{s.minutes} min</span>
                    <span className="block text-xs text-muted-foreground">{s.detail}</span>
                  </span>
                </label>
              ))}
            </div>
          </div>
          <div>
            <p className="mb-2 text-sm font-medium">Dicas para ganhar tempo</p>
            <ul className="list-disc space-y-1 pl-5 text-sm text-muted-foreground">
              {plan.tips.map((t, i) => <li key={i}>{t}</li>)}
            </ul>
          </div>
        </div>
      )}
    </div>
  );
}
