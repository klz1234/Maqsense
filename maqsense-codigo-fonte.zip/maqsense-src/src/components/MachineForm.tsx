import { useState } from "react";
import { Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { STATUS, parseSpecs, type Machine, type Spec } from "@/lib/machines";

export type MachineInput = {
  name: string;
  manufacturer: string;
  model: string;
  serial_number: string;
  category: string;
  location: string;
  installed_at: string | null;
  next_maintenance_at: string | null;
  next_maintenance_task: string;
  next_maintenance_done: boolean;
  maintenance_interval_days: number | null;
  status: string;
  notes: string;
  specs: Spec[];
};

export function MachineForm({
  initial,
  onSubmit,
  submitLabel,
}: {
  initial?: Machine;
  onSubmit: (v: MachineInput) => Promise<void>;
  submitLabel: string;
}) {
  const [v, setV] = useState<MachineInput>({
    name: initial?.name ?? "",
    manufacturer: initial?.manufacturer ?? "",
    model: initial?.model ?? "",
    serial_number: initial?.serial_number ?? "",
    category: initial?.category ?? "",
    location: initial?.location ?? "",
    installed_at: initial?.installed_at ?? null,
    next_maintenance_at: initial?.next_maintenance_at ?? null,
    next_maintenance_task: initial?.next_maintenance_task ?? "",
    next_maintenance_done: initial?.next_maintenance_done ?? false,
    maintenance_interval_days: initial?.maintenance_interval_days ?? null,
    status: initial?.status ?? "ok",
    notes: initial?.notes ?? "",
    specs: initial ? parseSpecs(initial.specs) : [{ label: "Potência", value: "" }, { label: "Rotação", value: "" }],
  });
  const [saving, setSaving] = useState(false);
  const set = (k: keyof MachineInput, val: string) => setV((p) => ({ ...p, [k]: val }));

  const fields: [keyof MachineInput, string, string?][] = [
    ["name", "Nome *", "Ex.: Compressor de ar 01"],
    ["manufacturer", "Fabricante", "Ex.: WEG, Atlas Copco"],
    ["model", "Modelo", "Ex.: W22 IR3"],
    ["serial_number", "Nº de série"],
    ["category", "Categoria", "Ex.: Motor elétrico, Bomba"],
    ["location", "Local", "Ex.: Linha 2 — Galpão B"],
  ];

  return (
    <form
      className="space-y-8"
      onSubmit={async (e) => {
        e.preventDefault();
        setSaving(true);
        await onSubmit({ ...v, specs: v.specs.filter((s) => s.label.trim()) });
        setSaving(false);
      }}
    >
      <section className="grid gap-4 rounded-sm border bg-card p-6 md:grid-cols-2">
        <p className="label-tech md:col-span-2">Identificação</p>
        {fields.map(([k, label, ph]) => (
          <div key={k} className="space-y-1.5">
            <Label htmlFor={k}>{label}</Label>
            <Input id={k} required={k === "name"} placeholder={ph} value={v[k] as string} onChange={(e) => set(k, e.target.value)} />
          </div>
        ))}
        <div className="space-y-1.5">
          <Label htmlFor="installed_at">Data de instalação</Label>
          <Input id="installed_at" type="date" value={v.installed_at ?? ""} onChange={(e) => setV((p) => ({ ...p, installed_at: e.target.value || null }))} />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="next_maintenance_at">Próxima manutenção</Label>
          <Input id="next_maintenance_at" type="date" value={v.next_maintenance_at ?? ""} onChange={(e) => setV((p) => ({ ...p, next_maintenance_at: e.target.value || null, next_maintenance_done: false }))} />
        </div>
        <div className="space-y-1.5 sm:col-span-2">
          <Label htmlFor="next_maintenance_task">Qual manutenção será feita</Label>
          <Input id="next_maintenance_task" placeholder="Ex.: Troca do óleo e dos filtros" value={v.next_maintenance_task} onChange={(e) => set("next_maintenance_task", e.target.value)} />
        </div>
        <div className="space-y-1.5 sm:col-span-2">
          <Label htmlFor="maintenance_interval_days">Repetir a cada (dias)</Label>
          <Input id="maintenance_interval_days" type="number" min="1" placeholder="Ex.: 90 — deixe vazio se não repetir" value={v.maintenance_interval_days ?? ""}
            onChange={(e) => setV((p) => ({ ...p, maintenance_interval_days: e.target.value ? Number(e.target.value) : null }))} />
          <p className="text-xs text-muted-foreground">Ao concluir a manutenção, a próxima data é calculada sozinha.</p>
        </div>
        <div className="space-y-1.5 sm:col-span-2">
          <Label>Essa manutenção já foi feita?</Label>
          <div className="flex gap-1 rounded-sm border p-1">
            {[{ k: false, t: "Ainda não" }, { k: true, t: "Sim, já foi feita" }].map((o) => (
              <button type="button" key={o.t} onClick={() => setV((p) => ({ ...p, next_maintenance_done: o.k }))}
                className={`flex-1 rounded-sm px-2 py-1 text-xs ${v.next_maintenance_done === o.k ? "bg-secondary" : "text-muted-foreground"}`}>{o.t}</button>
            ))}
          </div>
        </div>
        <div className="space-y-1.5">
          <Label>Estado</Label>
          <div className="flex gap-1 rounded-sm border p-1">
            {Object.entries(STATUS).map(([k, s]) => (
              <button type="button" key={k} onClick={() => set("status", k)}
                className={`flex-1 rounded-sm px-3 py-1 text-sm ${v.status === k ? "bg-secondary" : "text-muted-foreground"}`}>
                {s.label}
              </button>
            ))}
          </div>
        </div>
      </section>

      <section className="space-y-3 rounded-sm border bg-card p-6">
        <p className="label-tech">Especificações técnicas</p>
        {v.specs.map((s, i) => (
          <div key={i} className="flex gap-2">
            <Input placeholder="Parâmetro" value={s.label}
              onChange={(e) => setV((p) => ({ ...p, specs: p.specs.map((x, j) => (j === i ? { ...x, label: e.target.value } : x)) }))} />
            <Input placeholder="Valor (ex.: 15 kW)" value={s.value}
              onChange={(e) => setV((p) => ({ ...p, specs: p.specs.map((x, j) => (j === i ? { ...x, value: e.target.value } : x)) }))} />
            <Button type="button" variant="ghost" size="icon" aria-label="Remover"
              onClick={() => setV((p) => ({ ...p, specs: p.specs.filter((_, j) => j !== i) }))}>
              <X />
            </Button>
          </div>
        ))}
        <Button type="button" variant="outline" size="sm" onClick={() => setV((p) => ({ ...p, specs: [...p.specs, { label: "", value: "" }] }))}>
          <Plus /> Adicionar parâmetro
        </Button>
      </section>

      <section className="space-y-1.5 rounded-sm border bg-card p-6">
        <Label htmlFor="notes" className="label-tech">Observações</Label>
        <Textarea id="notes" value={v.notes} onChange={(e) => set("notes", e.target.value)} />
      </section>

      <Button type="submit" size="lg" disabled={saving}>{submitLabel}</Button>
    </form>
  );
}
