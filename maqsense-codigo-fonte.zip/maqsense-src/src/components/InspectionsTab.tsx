import { useMemo, useState } from "react";
import { useQueryClient, useSuspenseQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { CartesianGrid, Line, LineChart, ReferenceLine, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { StatusBadge } from "@/components/StatusBadge";
import { supabase } from "@/integrations/supabase/client";
import {
  STATUS, TECHNIQUES, inspectionsQuery, readingLevel, suggestedStatus,
  type Machine, type TechniqueKey,
} from "@/lib/machines";

const num = (v: unknown) => (v == null ? null : Number(v));
const fmtDate = (d: string) => new Date(d + "T00:00").toLocaleDateString("pt-BR");

export function InspectionsTab({ machine }: { machine: Machine }) {
  const { data: all } = useSuspenseQuery(inspectionsQuery(machine.id));
  const qc = useQueryClient();
  const [tech, setTech] = useState<TechniqueKey>("vibracao");
  const last = [...all].reverse().find((r) => r.technique === tech);
  const [form, setForm] = useState({ measured_at: new Date().toISOString().slice(0, 10), value: "", alert_limit: "", critical_limit: "", notes: "" });

  const readings = useMemo(() => all.filter((r) => r.technique === tech), [all, tech]);
  const chart = readings.map((r) => ({ date: fmtDate(r.measured_at), value: Number(r.value) }));
  const alertL = num(last?.alert_limit);
  const critL = num(last?.critical_limit);
  const suggested = suggestedStatus(all);

  async function add(e: React.FormEvent) {
    e.preventDefault();
    const { error } = await supabase.from("inspections").insert({
      machine_id: machine.id, technique: tech, unit: TECHNIQUES[tech].unit,
      measured_at: form.measured_at, value: Number(form.value), notes: form.notes,
      alert_limit: form.alert_limit ? Number(form.alert_limit) : alertL,
      critical_limit: form.critical_limit ? Number(form.critical_limit) : critL,
    });
    if (error) return void toast.error("Não foi possível registrar.");
    setForm((f) => ({ ...f, value: "", notes: "" }));
    qc.invalidateQueries({ queryKey: ["inspections", machine.id] });
    toast.success("Leitura registrada.");
  }

  async function applyStatus() {
    await supabase.from("machines").update({ status: suggested }).eq("id", machine.id);
    qc.invalidateQueries({ queryKey: ["machine", machine.id] });
    qc.invalidateQueries({ queryKey: ["machines"] });
    toast.success("Estado da máquina atualizado.");
  }

  async function del(id: string) {
    await supabase.from("inspections").delete().eq("id", id);
    qc.invalidateQueries({ queryKey: ["inspections", machine.id] });
  }

  return (
    <div className="space-y-6">
      {all.length > 0 && suggested !== machine.status && (
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-sm border border-warning/40 bg-card p-4 text-sm">
          <span>As últimas leituras indicam o estado <b>{STATUS[suggested].label}</b>.</span>
          <Button size="sm" onClick={applyStatus}>Atualizar estado da máquina</Button>
        </div>
      )}

      <div className="flex flex-wrap gap-1 rounded-sm border p-1">
        {(Object.keys(TECHNIQUES) as TechniqueKey[]).map((k) => (
          <button key={k} onClick={() => setTech(k)}
            className={`rounded-sm px-3 py-1 text-sm ${tech === k ? "bg-secondary" : "text-muted-foreground"}`}>
            {TECHNIQUES[k].label}
          </button>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-[1fr_320px]">
        <div className="space-y-6">
          <div className="rounded-sm border bg-card p-4">
            <p className="label-tech">Tendência · {TECHNIQUES[tech].label} ({TECHNIQUES[tech].unit})</p>
            {chart.length < 2 ? (
              <p className="py-16 text-center text-sm text-muted-foreground">Registre ao menos duas leituras para ver a tendência.</p>
            ) : (
              <div className="mt-4 h-64">
                <ResponsiveContainer>
                  <LineChart data={chart}>
                    <CartesianGrid stroke="var(--border)" strokeDasharray="3 3" />
                    <XAxis dataKey="date" stroke="var(--muted-foreground)" fontSize={11} />
                    <YAxis stroke="var(--muted-foreground)" fontSize={11} />
                    <Tooltip contentStyle={{ background: "var(--popover)", border: "1px solid var(--border)" }} />
                    {alertL != null && <ReferenceLine y={alertL} stroke="var(--warning)" strokeDasharray="4 4" label={{ value: "Alerta", fill: "var(--warning)", fontSize: 11 }} />}
                    {critL != null && <ReferenceLine y={critL} stroke="var(--destructive)" strokeDasharray="4 4" label={{ value: "Crítico", fill: "var(--destructive)", fontSize: 11 }} />}
                    <Line type="monotone" dataKey="value" stroke="var(--primary)" strokeWidth={2} dot={{ r: 3 }} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>
          <div className="rounded-sm border bg-card">
            {readings.length === 0 && <p className="p-6 text-sm text-muted-foreground">Nenhuma leitura de {TECHNIQUES[tech].label.toLowerCase()}.</p>}
            {[...readings].reverse().map((r) => (
              <div key={r.id} className="flex items-center gap-4 border-b p-4 last:border-b-0">
                <span className="w-24 font-mono-ui text-xs text-muted-foreground">{fmtDate(r.measured_at)}</span>
                <span className="flex-1 font-mono-ui">{Number(r.value)} {r.unit}{r.notes && <span className="ml-3 font-sans text-sm text-muted-foreground">{r.notes}</span>}</span>
                <StatusBadge status={readingLevel({ value: Number(r.value), alert_limit: num(r.alert_limit), critical_limit: num(r.critical_limit) })} />
                <Button variant="ghost" size="icon" aria-label="Excluir leitura" onClick={() => del(r.id)}><Trash2 /></Button>
              </div>
            ))}
          </div>
        </div>
        <form onSubmit={add} className="space-y-3 rounded-sm border bg-card p-4">
          <p className="label-tech">Nova leitura · {TECHNIQUES[tech].label}</p>
          <Input type="date" required value={form.measured_at} onChange={(e) => setForm({ ...form, measured_at: e.target.value })} />
          <Input type="number" step="any" required placeholder={`Valor (${TECHNIQUES[tech].unit})`} value={form.value} onChange={(e) => setForm({ ...form, value: e.target.value })} />
          <div className="flex gap-2">
            <Input type="number" step="any" placeholder={alertL != null ? `Alerta: ${alertL}` : "Limite alerta"} value={form.alert_limit} onChange={(e) => setForm({ ...form, alert_limit: e.target.value })} />
            <Input type="number" step="any" placeholder={critL != null ? `Crítico: ${critL}` : "Limite crítico"} value={form.critical_limit} onChange={(e) => setForm({ ...form, critical_limit: e.target.value })} />
          </div>
          <p className="text-xs text-muted-foreground">Limites em branco repetem os da última leitura.</p>
          <Input placeholder="Observação" value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} />
          <Button type="submit" className="w-full">Registrar leitura</Button>
        </form>
      </div>
    </div>
  );
}
