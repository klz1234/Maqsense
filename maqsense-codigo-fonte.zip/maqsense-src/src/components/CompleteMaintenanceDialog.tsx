import { useState, type ReactNode } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { MAINTENANCE_KINDS, afterCompletion, buildChecklist, checklistTemplatesQuery, templateItems, uploadMaintenancePhotos, type Machine } from "@/lib/machines";

type M = Pick<Machine, "id" | "name" | "next_maintenance_task" | "maintenance_interval_days">;

export function CompleteMaintenanceDialog({ machine, children }: { machine: M; children: ReactNode }) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const { data: ts = [] } = useQuery(checklistTemplatesQuery());
  const [kind, setKind] = useState<string>("preventiva");
  const items = templateItems(ts, kind);
  const [checked, setChecked] = useState<Set<string>>(new Set());
  const [before, setBefore] = useState<File[]>([]);
  const [after, setAfter] = useState<File[]>([]);
  const [f, setF] = useState({ performed_at: new Date().toLocaleDateString("en-CA"), technician: "", notes: "", parts_used: "", downtime: "" });

  async function save(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const task = machine.next_maintenance_task?.trim();
    const description = [task, f.notes.trim()].filter(Boolean).join(" — ");
    const { data: rec, error } = await supabase.from("maintenance_records").insert({
      machine_id: machine.id, performed_at: f.performed_at, kind,
      technician: f.technician, description, parts_used: f.parts_used,
      downtime_hours: f.downtime ? Number(f.downtime) : null,
      checklist: buildChecklist(items, checked),
    }).select("id").single();
    if (rec && (before.length || after.length)) {
      const photos = await uploadMaintenancePhotos(machine.id, rec.id, [
        ...before.map((file) => ({ file, phase: "antes" as const })),
        ...after.map((file) => ({ file, phase: "depois" as const })),
      ]);
      await supabase.from("maintenance_records").update({ photos }).eq("id", rec.id);
    }
    const patch = afterCompletion(machine.maintenance_interval_days, f.performed_at);
    const { error: e2 } = error ? { error } : await supabase.from("machines").update(patch).eq("id", machine.id);
    setBusy(false);
    if (error || e2) return void toast.error("Não foi possível salvar.");
    await Promise.all([
      qc.invalidateQueries({ queryKey: ["machines"] }),
      qc.invalidateQueries({ queryKey: ["machine", machine.id] }),
      qc.invalidateQueries({ queryKey: ["maintenance", machine.id] }),
    ]);
    setOpen(false);
    toast.success("next_maintenance_at" in patch
      ? `Manutenção concluída. Próxima em ${new Date(patch.next_maintenance_at + "T00:00").toLocaleDateString("pt-BR")}.`
      : "Manutenção concluída e registrada no histórico.");
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{children}</DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>Concluir manutenção — {machine.name}</DialogTitle></DialogHeader>
        {machine.next_maintenance_task && <p className="text-sm text-muted-foreground">{machine.next_maintenance_task}</p>}
        <form onSubmit={save} className="space-y-3">
          <div className="space-y-1.5"><Label htmlFor="cm-date">Data da conclusão</Label>
            <Input id="cm-date" type="date" required value={f.performed_at} onChange={(e) => setF({ ...f, performed_at: e.target.value })} /></div>
          <div className="flex gap-1 rounded-sm border p-1">
            {MAINTENANCE_KINDS.map((k) => (
              <button type="button" key={k} onClick={() => { setKind(k); setChecked(new Set()); }}
                className={`flex-1 rounded-sm px-2 py-1 text-xs capitalize ${kind === k ? "bg-secondary" : "text-muted-foreground"}`}>{k}</button>
            ))}
          </div>
          <div className="space-y-1.5 rounded-sm border p-3">
            <Label>Checklist ({checked.size}/{items.length})</Label>
            {items.length === 0 && <p className="text-xs text-muted-foreground">Sem checklist para {kind}. Crie um na aba Histórico.</p>}
            {items.map((it) => (
              <label key={it} className="flex items-center gap-2 text-sm">
                <Checkbox checked={checked.has(it)} onCheckedChange={(c) => setChecked((p) => { const n = new Set(p); c ? n.add(it) : n.delete(it); return n; })} />
                {it}
              </label>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label htmlFor="cm-before">Fotos antes</Label>
              <Input id="cm-before" type="file" accept="image/*" multiple onChange={(e) => setBefore([...(e.target.files ?? [])])} /></div>
            <div className="space-y-1.5"><Label htmlFor="cm-after">Fotos depois</Label>
              <Input id="cm-after" type="file" accept="image/*" multiple onChange={(e) => setAfter([...(e.target.files ?? [])])} /></div>
          </div>
          <div className="space-y-1.5"><Label htmlFor="cm-tech">Responsável</Label>
            <Input id="cm-tech" required value={f.technician} onChange={(e) => setF({ ...f, technician: e.target.value })} /></div>
          <div className="space-y-1.5"><Label htmlFor="cm-parts">Peças utilizadas</Label>
            <Input id="cm-parts" placeholder="Ex.: 1 filtro de óleo, 4 L de óleo ISO 46" value={f.parts_used} onChange={(e) => setF({ ...f, parts_used: e.target.value })} /></div>
          <div className="space-y-1.5"><Label htmlFor="cm-notes">Observações</Label>
            <Textarea id="cm-notes" value={f.notes} onChange={(e) => setF({ ...f, notes: e.target.value })} /></div>
          <div className="space-y-1.5"><Label htmlFor="cm-dt">Tempo parado (horas)</Label>
            <Input id="cm-dt" type="number" step="0.1" min="0" value={f.downtime} onChange={(e) => setF({ ...f, downtime: e.target.value })} /></div>
          <p className="text-xs text-muted-foreground">
            {machine.maintenance_interval_days
              ? `A próxima manutenção será marcada para ${machine.maintenance_interval_days} dias após a conclusão.`
              : "Esta máquina não tem intervalo definido; edite a máquina para repetir automaticamente."}
          </p>
          <Button type="submit" className="w-full" disabled={busy}>Concluir e registrar</Button>
        </form>
      </DialogContent>
    </Dialog>
  );
}
