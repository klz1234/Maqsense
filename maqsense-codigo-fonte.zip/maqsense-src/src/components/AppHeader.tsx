import { Link, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { LogOut } from "lucide-react";
import logo from "@/assets/maqsense-logo.png";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { MaintenanceBell } from "@/components/MaintenanceBell";

export function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2 font-bold tracking-tight">
      <img src={logo} alt="" width={32} height={32} className="size-8 rounded-sm" />
      MaqSense
    </Link>
  );
}

export function AppHeader() {
  const qc = useQueryClient();
  const navigate = useNavigate();

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  return (
    <header className="border-b bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between px-4">
        <div className="flex items-center gap-6">
          <Logo />
          <nav className="flex gap-4 text-sm text-muted-foreground">
            <Link to="/painel" activeProps={{ className: "text-foreground" }}>
              Painel
            </Link>
            <Link to="/checklists" activeProps={{ className: "text-foreground" }}>
              Checklists
            </Link>
            <Link to="/pecas" activeProps={{ className: "text-foreground" }}>
              Peças
            </Link>
            <Link to="/maquinas" activeOptions={{ exact: true }} activeProps={{ className: "text-foreground" }}>
              Máquinas
            </Link>
            <Link to="/maquinas/nova" activeProps={{ className: "text-foreground" }}>
              Cadastrar
            </Link>
          </nav>
        </div>
        <div className="flex items-center gap-1">
          <MaintenanceBell />
          <Button variant="ghost" size="sm" onClick={signOut}>
            <LogOut /> Sair
          </Button>
        </div>
      </div>
    </header>
  );
}
