import { STATUS, type StatusKey } from "@/lib/machines";
import { cn } from "@/lib/utils";

const toneClass = {
  success: "border-success/40 text-success",
  warning: "border-warning/40 text-warning",
  destructive: "border-destructive/40 text-destructive",
};

export function StatusBadge({ status }: { status: string }) {
  const s = STATUS[(status as StatusKey) in STATUS ? (status as StatusKey) : "ok"];
  return (
    <span className={cn("inline-flex items-center gap-1.5 rounded-sm border px-2 py-0.5 font-mono-ui text-xs", toneClass[s.tone])}>
      <span className="size-1.5 rounded-full bg-current" />
      {s.label}
    </span>
  );
}
