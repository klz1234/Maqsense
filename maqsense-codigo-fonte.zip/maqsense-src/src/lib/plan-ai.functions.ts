import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type MaintenancePlan = {
  steps: { title: string; detail: string; minutes: number }[];
  parts: { name: string; qty: string }[];
  tools: string[];
  tips: string[];
};

/** AI checklist to make the next maintenance faster: steps, parts to set aside, tools, time-saving tips. */
export const planMaintenance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { machineId: string }) => input)
  .handler(async ({ data, context }) => {
    const { data: m } = await context.supabase
      .from("machines")
      .select("name, manufacturer, model, category, specs, notes")
      .eq("id", data.machineId)
      .maybeSingle();
    if (!m) throw new Error("Máquina não encontrada.");
    const { data: hist } = await context.supabase
      .from("maintenance_records")
      .select("performed_at, kind, description, downtime_hours")
      .eq("machine_id", data.machineId)
      .order("performed_at", { ascending: false })
      .limit(10);
    const { data: insp } = await context.supabase
      .from("inspections")
      .select("measured_at, technique, value, unit, alert_limit, critical_limit")
      .eq("machine_id", data.machineId)
      .order("measured_at", { ascending: false })
      .limit(10);

    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("IA não configurada.");

    const [{ createOpenAI }, { streamText, Output, NoObjectGeneratedError }, { z }] = await Promise.all([
      import("@ai-sdk/openai"),
      import("ai"),
      import("zod"),
    ]);

    let runId: string | undefined;
    const provider = createOpenAI({
      baseURL: "https://ai.gateway.lovable.dev/v1",
      apiKey,
      headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
      fetch: async (input, init) => {
        const headers = new Headers(init?.headers);
        if (runId) headers.set("X-Lovable-AIG-Run-ID", runId);
        const res = await fetch(input, { ...init, headers });
        runId ??= res.headers.get("X-Lovable-AIG-Run-ID") ?? undefined;
        return res;
      },
    });

    const schema = z.object({
      steps: z.array(z.object({ title: z.string(), detail: z.string(), minutes: z.number() })),
      parts: z.array(z.object({ name: z.string(), qty: z.string() })),
      tools: z.array(z.string()),
      tips: z.array(z.string()),
    });

    const result = streamText({
      model: provider.responses("openai/gpt-6-astra"),
      system:
        "Você é um especialista em manutenção industrial. Responda em português do Brasil. " +
        "Monte um plano para a próxima manutenção preventiva do equipamento que reduza o tempo de máquina parada: " +
        "steps (6 a 12 passos em ordem, com detalhe curto e minutos estimados; inclua segurança/bloqueio de energia), " +
        "parts (peças e consumíveis a separar ANTES da parada, com quantidade provável), tools (ferramentas e instrumentos), " +
        "tips (3 a 5 dicas para ganhar tempo, ex.: o que preparar com a máquina ainda rodando). " +
        "Use o histórico e as inspeções para priorizar problemas recorrentes. Seja prático e não invente códigos de peça.",
      prompt:
        `Equipamento: ${m.name}\nFabricante: ${m.manufacturer || "?"}\nModelo: ${m.model || "?"}\nCategoria: ${m.category || "?"}\n` +
        `Especificações: ${JSON.stringify(m.specs)}\nObservações: ${m.notes || "-"}\n` +
        `Histórico recente: ${JSON.stringify(hist ?? [])}\nInspeções recentes: ${JSON.stringify(insp ?? [])}`,
      output: Output.object({ schema }),
      providerOptions: {
        openai: {
          forceReasoning: true,
          reasoningEffort: "low",
          reasoningSummary: "auto",
          store: false,
          include: ["reasoning.encrypted_content"],
        },
      },
    });

    try {
      return (await result.output) as MaintenancePlan;
    } catch (e) {
      if (NoObjectGeneratedError.isInstance(e)) throw new Error("A IA não retornou um plano válido.");
      const status = (e as { statusCode?: number }).statusCode;
      if (status === 402) throw new Error("Créditos de IA esgotados.");
      if (status === 429) throw new Error("Muitas solicitações. Tente novamente em instantes.");
      throw new Error("Não foi possível gerar o plano agora.");
    }
  });
