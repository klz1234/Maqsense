import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export type ManualSuggestion = { title: string; kind: string; why: string; query: string };

/** AI suggestions of which manufacturer documents to look for, based on the machine's data. */
export const suggestManuals = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { machineId: string }) => input)
  .handler(async ({ data, context }) => {
    const { data: m, error } = await context.supabase
      .from("machines")
      .select("name, manufacturer, model, category, specs")
      .eq("id", data.machineId)
      .maybeSingle();
    if (error || !m) throw new Error("Máquina não encontrada.");

    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) throw new Error("IA não configurada.");

    const [{ createOpenAI }, { streamText, Output, NoObjectGeneratedError }, { z }] = await Promise.all([
      import("@ai-sdk/openai"),
      import("ai"),
      import("zod"),
    ]);

    let runId: string | undefined;
    const provider = createOpenAI({
      baseURL: "https://ai.gateway.lovable.dev/v1",
      apiKey,
      headers: { "Lovable-API-Key": apiKey, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
      fetch: async (input, init) => {
        const headers = new Headers(init?.headers);
        if (runId) headers.set("X-Lovable-AIG-Run-ID", runId);
        const res = await fetch(input, { ...init, headers });
        runId ??= res.headers.get("X-Lovable-AIG-Run-ID") ?? undefined;
        return res;
      },
    });

    const schema = z.object({
      suggestions: z.array(
        z.object({ title: z.string(), kind: z.string(), why: z.string(), query: z.string() }),
      ),
    });

    const result = streamText({
      model: provider.responses("openai/gpt-6-astra"),
      system:
        "Você é um especialista em manutenção industrial. Responda em português do Brasil. " +
        "Sugira de 3 a 6 documentos do fabricante úteis para manutenção preditiva do equipamento " +
        "(manual de operação, manual de manutenção, catálogo de peças, folha de dados, boletins). " +
        "Não invente URLs. Para cada um, dê: title (nome provável do documento), kind (tipo curto), " +
        "why (uma frase sobre por que é útil) e query (termos de busca no Google para encontrá-lo, em inglês ou português).",
      prompt: `Equipamento: ${m.name}\nFabricante: ${m.manufacturer || "?"}\nModelo: ${m.model || "?"}\nCategoria: ${m.category || "?"}\nEspecificações: ${JSON.stringify(m.specs)}`,
      output: Output.object({ schema }),
      providerOptions: {
        openai: {
          forceReasoning: true,
          reasoningEffort: "low",
          reasoningSummary: "auto",
          store: false,
          include: ["reasoning.encrypted_content"],
        },
      },
    });

    try {
      const out = await result.output;
      return { suggestions: out.suggestions.slice(0, 6) as ManualSuggestion[] };
    } catch (e) {
      if (NoObjectGeneratedError.isInstance(e)) throw new Error("A IA não retornou sugestões válidas.");
      const status = (e as { statusCode?: number }).statusCode;
      if (status === 402) throw new Error("Créditos de IA esgotados.");
      if (status === 429) throw new Error("Muitas solicitações. Tente novamente em instantes.");
      throw new Error("Não foi possível gerar sugestões agora.");
    }
  });
