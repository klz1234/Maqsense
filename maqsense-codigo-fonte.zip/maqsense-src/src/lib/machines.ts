import { queryOptions } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import type { Tables } from "@/integrations/supabase/types";

export type Machine = Tables<"machines">;
export type MaintenanceRecord = Tables<"maintenance_records">;
export type Manual = Tables<"manuals">;
export type Spec = { label: string; value: string };

export const STATUS = {
  ok: { label: "Operando", tone: "success" },
  atencao: { label: "Atenção", tone: "warning" },
  critico: { label: "Crítico", tone: "destructive" },
} as const;
export type StatusKey = keyof typeof STATUS;

export const MAINTENANCE_KINDS = ["preventiva", "corretiva", "preditiva"] as const;

export const machinesQuery = () =>
  queryOptions({
    queryKey: ["machines"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("machines")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

export const machineQuery = (id: string) =>
  queryOptions({
    queryKey: ["machine", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("machines").select("*").eq("id", id).maybeSingle();
      if (error) throw error;
      return data;
    },
  });

export const maintenanceQuery = (machineId: string) =>
  queryOptions({
    queryKey: ["maintenance", machineId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("maintenance_records")
        .select("*")
        .eq("machine_id", machineId)
        .order("performed_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

export const manualsQuery = (machineId: string) =>
  queryOptions({
    queryKey: ["manuals", machineId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("manuals")
        .select("*")
        .eq("machine_id", machineId)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

export function parseSpecs(specs: unknown): Spec[] {
  if (!Array.isArray(specs)) return [];
  return specs.filter(
    (s): s is Spec => !!s && typeof s === "object" && "label" in s && "value" in s,
  );
}

/** Case/accent-insensitive search across the main identifying fields. */
export function matchesSearch(m: Pick<Machine, "name" | "manufacturer" | "model" | "serial_number" | "location" | "category">, term: string) {
  const norm = (s: string) => s.normalize("NFD").replace(/\p{Diacritic}/gu, "").toLowerCase();
  const t = norm(term.trim());
  if (!t) return true;
  return [m.name, m.manufacturer, m.model, m.serial_number, m.location, m.category].some((f) =>
    norm(f ?? "").includes(t),
  );
}

/** External search links for manufacturer manuals, built from manufacturer + model. */
export function manualSearchLinks(m: Pick<Machine, "manufacturer" | "model" | "name">) {
  const base = [m.manufacturer, m.model || m.name].filter(Boolean).join(" ").trim();
  const q = (s: string) => encodeURIComponent(s);
  return [
    { label: "Manual em PDF", href: `https://www.google.com/search?q=${q(`${base} manual filetype:pdf`)}` },
    { label: "Site do fabricante", href: `https://www.google.com/search?q=${q(`${base} manual site oficial`)}` },
    { label: "ManualsLib", href: `https://www.manualslib.com/brand/?q=${q(base)}` },
  ];
}

export type Inspection = Tables<"inspections">;

export const TECHNIQUES = {
  vibracao: { label: "Vibração", unit: "mm/s" },
  temperatura: { label: "Temperatura", unit: "°C" },
  ruido: { label: "Ruído", unit: "dB" },
  oleo: { label: "Análise de óleo", unit: "ppm" },
  termografia: { label: "Termografia", unit: "°C" },
} as const;
export type TechniqueKey = keyof typeof TECHNIQUES;

export const inspectionsQuery = (machineId: string) =>
  queryOptions({
    queryKey: ["inspections", machineId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("inspections")
        .select("*")
        .eq("machine_id", machineId)
        .order("measured_at", { ascending: true });
      if (error) throw error;
      return data;
    },
  });

/** Reading level: critical when value >= critical limit, alert when >= alert limit. */
export function readingLevel(r: { value: number; alert_limit: number | null; critical_limit: number | null }): StatusKey {
  if (r.critical_limit != null && r.value >= r.critical_limit) return "critico";
  if (r.alert_limit != null && r.value >= r.alert_limit) return "atencao";
  return "ok";
}

/** Machine level suggested by the latest reading of each technique (worst wins). */
export function suggestedStatus(readings: Inspection[]): StatusKey {
  const latest = new Map<string, Inspection>();
  for (const r of readings) {
    const prev = latest.get(r.technique);
    if (!prev || r.measured_at >= prev.measured_at) latest.set(r.technique, r);
  }
  const levels = [...latest.values()].map((r) =>
    readingLevel({ value: Number(r.value), alert_limit: r.alert_limit == null ? null : Number(r.alert_limit), critical_limit: r.critical_limit == null ? null : Number(r.critical_limit) }),
  );
  return levels.includes("critico") ? "critico" : levels.includes("atencao") ? "atencao" : "ok";
}

export const allInspectionsQuery = () =>
  queryOptions({
    queryKey: ["inspections", "all"],
    queryFn: async () => {
      const { data, error } = await supabase.from("inspections").select("*");
      if (error) throw error;
      return data;
    },
  });

/** Days from `today` until `date` (negative = overdue). Both as YYYY-MM-DD. */
export function daysUntil(date: string, today: string): number {
  return Math.round((Date.parse(date + "T00:00Z") - Date.parse(today + "T00:00Z")) / 86400000);
}

/** Maintenance is "upcoming" when overdue or due within `windowDays`. */
type Due = { next_maintenance_at: string | null; next_maintenance_done?: boolean | null };
export function upcomingMaintenance<T extends Due>(ms: T[], today: string, windowDays = 30) {
  return ms
    .filter((m) => !m.next_maintenance_done && m.next_maintenance_at && daysUntil(m.next_maintenance_at, today) <= windowDays)
    .sort((a, b) => a.next_maintenance_at!.localeCompare(b.next_maintenance_at!));
}

/** In-site notice window: maintenance due within this many days (or overdue). */
export const NOTICE_DAYS = 7;
export const dueSoon = <T extends Due>(ms: T[], today: string) =>
  upcomingMaintenance(ms, today, NOTICE_DAYS);

/** Total downtime hours across records (ignores empty values). */
export const totalDowntime = (rs: { downtime_hours: number | null }[]) =>
  rs.reduce((s, r) => s + (r.downtime_hours == null ? 0 : Number(r.downtime_hours)), 0);

/** Adds `days` to a YYYY-MM-DD date. */
export function addDays(date: string, days: number): string {
  return new Date(Date.parse(date + "T00:00Z") + days * 86400000).toISOString().slice(0, 10);
}

/** Machine changes after completing its maintenance: with an interval, schedule the next one from the completion date. */
export function afterCompletion(intervalDays: number | null, performedAt: string) {
  return intervalDays && intervalDays > 0
    ? { next_maintenance_at: addDays(performedAt, intervalDays), next_maintenance_done: false }
    : { next_maintenance_done: true };
}

export type ChecklistEntry = { item: string; checked: boolean };
export type MaintenancePhoto = { path: string; phase: "antes" | "depois" };

export const checklistTemplatesQuery = () =>
  queryOptions({
    queryKey: ["checklist-templates"],
    queryFn: async () => {
      const { data, error } = await supabase.from("checklist_templates").select("*");
      if (error) throw error;
      return data;
    },
  });

const strArr = (v: unknown): string[] => (Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : []);
export const templateItems = (ts: { kind: string; items: unknown }[], kind: string) =>
  strArr(ts.find((t) => t.kind === kind)?.items);

/** Records every template item with whether it was verified in this service. */
export const buildChecklist = (items: string[], checked: Set<string>): ChecklistEntry[] =>
  items.map((item) => ({ item, checked: checked.has(item) }));

export function parseChecklist(v: unknown): ChecklistEntry[] {
  return Array.isArray(v) ? v.filter((x): x is ChecklistEntry => !!x && typeof x === "object" && "item" in x) : [];
}
export function parsePhotos(v: unknown): MaintenancePhoto[] {
  return Array.isArray(v) ? v.filter((x): x is MaintenancePhoto => !!x && typeof x === "object" && "path" in x) : [];
}

/** Uploads photos under <user>/<machine>/<record>/ in the private bucket. */
export async function uploadMaintenancePhotos(machineId: string, recordId: string, files: { file: File; phase: MaintenancePhoto["phase"] }[]) {
  const { data: u } = await supabase.auth.getUser();
  const out: MaintenancePhoto[] = [];
  for (const { file, phase } of files) {
    const path = `${u.user!.id}/${machineId}/${recordId}/${phase}-${crypto.randomUUID()}-${file.name.replace(/[^\w.-]/g, "_")}`;
    const { error } = await supabase.storage.from("maintenance-photos").upload(path, file);
    if (!error) out.push({ path, phase });
  }
  return out;
}

export const allMaintenanceQuery = () =>
  queryOptions({
    queryKey: ["maintenance", "all"],
    queryFn: async () => {
      const { data, error } = await supabase.from("maintenance_records").select("*");
      if (error) throw error;
      return data;
    },
  });

export type ItemStat = { item: string; total: number; missed: number };
export type ChecklistGroup = { machine_id: string; kind: string; checked: number; total: number; items: ItemStat[] };

/** Completion rate per machine + maintenance kind, with per-item miss counts (most missed first). */
export function checklistStats(records: { machine_id: string; kind: string; checklist: unknown }[]): ChecklistGroup[] {
  const groups = new Map<string, ChecklistGroup>();
  for (const r of records) {
    const cl = parseChecklist(r.checklist);
    if (!cl.length) continue;
    const key = r.machine_id + "|" + r.kind;
    const g = groups.get(key) ?? { machine_id: r.machine_id, kind: r.kind, checked: 0, total: 0, items: [] };
    for (const c of cl) {
      g.total++;
      if (c.checked) g.checked++;
      let s = g.items.find((i) => i.item === c.item);
      if (!s) g.items.push((s = { item: c.item, total: 0, missed: 0 }));
      s.total++;
      if (!c.checked) s.missed++;
    }
    groups.set(key, g);
  }
  for (const g of groups.values()) g.items.sort((a, b) => b.missed / b.total - a.missed / a.total);
  return [...groups.values()].sort((a, b) => a.checked / a.total - b.checked / b.total);
}

/** An item is "frequently missed" when skipped in at least half of the services (min. 2 occurrences). */
export const frequentlyMissed = (s: ItemStat) => s.total >= 2 && s.missed / s.total >= 0.5;

export type RecordFilter = { from?: string; to?: string; machineId?: string; kind?: string };
/** Keeps records inside the period (inclusive) and matching machine/kind when set. */
export const filterRecords = <T extends { performed_at: string; machine_id: string; kind: string }>(rs: T[], f: RecordFilter) =>
  rs.filter((r) =>
    (!f.from || r.performed_at >= f.from) && (!f.to || r.performed_at <= f.to) &&
    (!f.machineId || r.machine_id === f.machineId) && (!f.kind || r.kind === f.kind));

const rate = (g: { checked: number; total: number }) => (g.total ? Math.round((g.checked / g.total) * 100) : null);
export type PeriodRow = { machine_id: string; kind: string; a: number | null; b: number | null; diff: number | null };
/** Side-by-side completion rate per machine + kind for two period group sets (diff = B − A, points). */
export function comparePeriods(a: ChecklistGroup[], b: ChecklistGroup[]): PeriodRow[] {
  const keys = new Map<string, { machine_id: string; kind: string }>();
  [...a, ...b].forEach((g) => keys.set(g.machine_id + "|" + g.kind, g));
  return [...keys.entries()].map(([k, g]) => {
    const ra = a.find((x) => x.machine_id + "|" + x.kind === k), rb = b.find((x) => x.machine_id + "|" + x.kind === k);
    const va = ra ? rate(ra) : null, vb = rb ? rate(rb) : null;
    return { machine_id: g.machine_id, kind: g.kind, a: va, b: vb, diff: va != null && vb != null ? vb - va : null };
  });
}

/** CSV (semicolon, pt-BR Excel friendly) with one row per checklist item of each machine + kind. */
export function checklistCsv(groups: ChecklistGroup[], names: Map<string, string>): string {
  const esc = (v: string | number) => `"${String(v).replace(/"/g, '""')}"`;
  const rows = [["Máquina", "Tipo", "Taxa do grupo (%)", "Item", "Verificados", "Total", "Taxa do item (%)", "Frequentemente esquecido"]];
  for (const g of groups) for (const i of g.items)
    rows.push([names.get(g.machine_id) ?? "Máquina", g.kind, String(rate(g)), i.item, String(i.total - i.missed), String(i.total), String(Math.round(((i.total - i.missed) / i.total) * 100)), frequentlyMissed(i) ? "sim" : "não"]);
  return rows.map((r) => r.map(esc).join(";")).join("\n");
}

export type Part = Tables<"parts">;
export const PART_STATUS = {
  quebrada: { label: "Quebrada", cls: "text-destructive" },
  comprar: { label: "Precisa comprar", cls: "text-primary" },
  comprada: { label: "Comprada", cls: "text-success" },
} as const;
export type PartStatus = keyof typeof PART_STATUS;
export const partsQuery = () =>
  queryOptions({
    queryKey: ["parts"],
    queryFn: async () => {
      const { data, error } = await supabase.from("parts").select("*").order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

export type PartFilter = { term?: string; machineId?: string; status?: string; from?: string; to?: string };
/** Filters parts by text (name/supplier/notes, accent-insensitive), machine, status and registration date (inclusive). */
export function filterParts<T extends { name: string; supplier: string; notes: string; machine_id: string | null; status: string; created_at: string }>(ps: T[], f: PartFilter) {
  const norm = (s: string) => s.normalize("NFD").replace(/\p{Diacritic}/gu, "").toLowerCase();
  const t = norm((f.term ?? "").trim());
  return ps.filter((p) => {
    const d = p.created_at.slice(0, 10);
    return (!t || [p.name, p.supplier, p.notes].some((x) => norm(x).includes(t))) &&
      (!f.machineId || p.machine_id === f.machineId) && (!f.status || p.status === f.status) &&
      (!f.from || d >= f.from) && (!f.to || d <= f.to);
  });
}
/** Total cost = quantity × unit price, ignoring parts without price. */
export const partsCost = (ps: { quantity: number; unit_price: number | null }[]) =>
  ps.reduce((s, p) => s + (p.unit_price == null ? 0 : p.quantity * Number(p.unit_price)), 0);
