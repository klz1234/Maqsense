import { frequentlyMissed, type ChecklistGroup } from "@/lib/machines";

/** PDF of the checklist dashboard: rates per machine + kind and frequently missed items. */
export async function downloadChecklistReport(groups: ChecklistGroup[], names: Map<string, string>, filterLabel: string) {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = 210, M = 15;
  let y = M;
  const need = (h: number) => { if (y + h > 297 - M) { doc.addPage(); y = M; } };
  const text = (t: string, size = 10, bold = false, color = 30) => {
    doc.setFont("helvetica", bold ? "bold" : "normal").setFontSize(size).setTextColor(color);
    const lines = doc.splitTextToSize(t, W - 2 * M) as string[];
    need(lines.length * size * 0.45);
    doc.text(lines, M, y + size * 0.35);
    y += lines.length * size * 0.45 + 1.5;
  };
  const pct = (a: number, b: number) => Math.round((a / b) * 100);
  const checked = groups.reduce((s, g) => s + g.checked, 0), total = groups.reduce((s, g) => s + g.total, 0);
  const name = (id: string) => names.get(id) ?? "Máquina";

  text("MaqSense — Relatório de checklists", 16, true);
  text(`Filtros: ${filterLabel}`, 9, false, 110);
  text(`Gerado em ${new Date().toLocaleString("pt-BR")}`, 9, false, 110);
  y += 3;
  text(`Taxa geral: ${total ? pct(checked, total) : 0}% (${checked} de ${total} itens verificados)`, 11, true);

  const missed = groups.flatMap((g) => g.items.filter(frequentlyMissed).map((i) => ({ i, g })));
  y += 3;
  text("ITENS FREQUENTEMENTE NÃO VERIFICADOS", 9, true, 180);
  if (!missed.length) text("Nenhum.");
  missed.forEach(({ i, g }) => text(`• ${i.item} — ${name(g.machine_id)} · ${g.kind} · esquecido em ${i.missed} de ${i.total}`, 10, false, 150));

  y += 3;
  text("TAXA POR MÁQUINA E TIPO", 9, true);
  for (const g of groups) {
    need(14);
    y += 2;
    const r = pct(g.checked, g.total);
    text(`${name(g.machine_id)} · ${g.kind} — ${r}%`, 11, true);
    doc.setFillColor(230, 230, 230).rect(M, y, 100, 2.5, "F");
    doc.setFillColor(r < 50 ? 200 : r < 80 ? 220 : 60, r < 50 ? 60 : r < 80 ? 150 : 160, r < 50 ? 60 : r < 80 ? 30 : 90).rect(M, y, r, 2.5, "F");
    y += 5;
    g.items.forEach((i) => text(`${frequentlyMissed(i) ? "! " : "   "}${i.item}: ${i.total - i.missed}/${i.total} verificados`, 9, frequentlyMissed(i), frequentlyMissed(i) ? 180 : 70));
  }
  doc.save(`checklists-${new Date().toLocaleDateString("en-CA")}.pdf`);
}
