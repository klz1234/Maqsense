import { describe, expect, it } from "vitest";
import { manualSearchLinks, matchesSearch } from "./machines";

const m = { name: "Compressor 01", manufacturer: "Atlas Copco", model: "GA30", serial_number: "X1", location: "Galpão B", category: "Compressor" };

describe("pesquisa de máquinas", () => {
  it("encontra pelo fabricante ignorando acentos e maiúsculas", () => {
    expect(matchesSearch(m, "atlas")).toBe(true);
    expect(matchesSearch(m, "galpao")).toBe(true);
    expect(matchesSearch(m, "weg")).toBe(false);
  });
});

describe("busca de manuais", () => {
  it("usa fabricante e modelo do equipamento pesquisado", () => {
    expect(manualSearchLinks(m)[0]?.href).toContain(encodeURIComponent("Atlas Copco GA30 manual"));
  });
});

import { readingLevel, suggestedStatus } from "./machines";

describe("alertas de inspeção", () => {
  it("classifica pelo limite de alerta e crítico", () => {
    expect(readingLevel({ value: 2, alert_limit: 4.5, critical_limit: 7.1 })).toBe("ok");
    expect(readingLevel({ value: 4.5, alert_limit: 4.5, critical_limit: 7.1 })).toBe("atencao");
    expect(readingLevel({ value: 8, alert_limit: 4.5, critical_limit: 7.1 })).toBe("critico");
  });
  it("usa só a leitura mais recente de cada técnica", () => {
    const base = { id: "", user_id: "", machine_id: "", unit: "", notes: "", created_at: "", alert_limit: 4.5, critical_limit: 7.1 };
    const rs = [
      { ...base, technique: "vibracao", measured_at: "2026-01-01", value: 9 },
      { ...base, technique: "vibracao", measured_at: "2026-02-01", value: 5 },
    ];
    expect(suggestedStatus(rs)).toBe("atencao");
  });
});

import { upcomingMaintenance } from "./machines";
describe("manutenções próximas", () => {
  it("inclui atrasadas e as dos próximos 30 dias, em ordem", () => {
    const list = [
      { id: "a", next_maintenance_at: "2026-12-01" },
      { id: "b", next_maintenance_at: "2026-11-20" },
      { id: "c", next_maintenance_at: "2026-10-01" },
      { id: "d", next_maintenance_at: null },
    ];
    expect(upcomingMaintenance(list, "2026-10-23").map((m) => m.id)).toEqual(["c", "b"]);
  });
});

import { dueSoon as _dueSoon, totalDowntime as _totalDowntime } from "./machines";
describe("aviso de manutenção (7 dias)", () => {
  const today = "2026-10-23";
  it("inclui vencendo em 7 dias e atrasadas, exclui em 8 dias", () => {
    const r = _dueSoon([
      { next_maintenance_at: "2026-10-30" },
      { next_maintenance_at: "2026-10-31" },
      { next_maintenance_at: "2026-10-20" },
      { next_maintenance_at: null },
    ], today);
    expect(r.map((x) => x.next_maintenance_at)).toEqual(["2026-10-20", "2026-10-30"]);
  });
  it("soma horas paradas", () => {
    expect(_totalDowntime([{ downtime_hours: 2.5 }, { downtime_hours: null }, { downtime_hours: 4 }])).toBe(6.5);
  });
});

describe("manutenção já feita", () => {
  it("não gera aviso quando marcada como feita", () => {
    const r = _dueSoon([
      { id: "a", next_maintenance_at: "2026-10-25", next_maintenance_done: true },
      { id: "b", next_maintenance_at: "2026-10-25", next_maintenance_done: false },
    ], "2026-10-23");
    expect(r.map((m) => m.id)).toEqual(["b"]);
  });
});

import { afterCompletion } from "./machines";
describe("manutenção recorrente", () => {
  it("com intervalo de 90 dias, próxima data = conclusão + 90", () => {
    expect(afterCompletion(90, "2026-10-28")).toEqual({ next_maintenance_at: "2027-01-26", next_maintenance_done: false });
  });
  it("sem intervalo, apenas marca como feita", () => {
    expect(afterCompletion(null, "2026-10-28")).toEqual({ next_maintenance_done: true });
  });
});

import { buildChecklist, templateItems } from "./machines";
describe("checklist por tipo", () => {
  it("usa os itens do tipo escolhido", () => {
    expect(templateItems([{ kind: "preventiva", items: ["Óleo"] }, { kind: "corretiva", items: ["Peça"] }], "corretiva")).toEqual(["Peça"]);
  });
  it("registra itens verificados e não verificados", () => {
    expect(buildChecklist(["Óleo", "Filtro"], new Set(["Filtro"]))).toEqual([
      { item: "Óleo", checked: false }, { item: "Filtro", checked: true },
    ]);
  });
});

import { checklistStats, frequentlyMissed } from "./machines";
describe("painel de checklists", () => {
  const recs = [
    { machine_id: "m1", kind: "preventiva", checklist: [{ item: "Óleo", checked: true }, { item: "Filtro", checked: false }] },
    { machine_id: "m1", kind: "preventiva", checklist: [{ item: "Óleo", checked: true }, { item: "Filtro", checked: false }] },
  ];
  it("calcula taxa por máquina e tipo", () => {
    const g = checklistStats(recs)[0]!;
    expect([g.checked, g.total]).toEqual([2, 4]);
    expect(g.items[0]).toEqual({ item: "Filtro", total: 2, missed: 2 });
  });
  it("destaca item não verificado em metade ou mais dos serviços", () => {
    expect(frequentlyMissed({ item: "x", total: 2, missed: 1 })).toBe(true);
    expect(frequentlyMissed({ item: "x", total: 4, missed: 1 })).toBe(false);
  });
});

import { filterRecords } from "./machines";
describe("filtros do painel de checklists", () => {
  const rs = [
    { performed_at: "2026-09-10", machine_id: "a", kind: "preventiva" },
    { performed_at: "2026-10-10", machine_id: "a", kind: "corretiva" },
    { performed_at: "2026-10-20", machine_id: "b", kind: "preventiva" },
  ];
  it("filtra por período inclusivo", () => {
    expect(filterRecords(rs, { from: "2026-10-10", to: "2026-10-20" }).length).toBe(2);
  });
  it("filtra por máquina e tipo", () => {
    expect(filterRecords(rs, { machineId: "a", kind: "preventiva" })).toEqual([rs[0]]);
  });
});

import { comparePeriods, checklistCsv } from "./machines";
describe("comparação e CSV", () => {
  const g = (c: number, t: number) => ({ machine_id: "m", kind: "preventiva", checked: c, total: t, items: [{ item: "Óleo", total: t, missed: t - c }] });
  it("compara taxas entre dois períodos", () => {
    expect(comparePeriods([g(1, 2)], [g(3, 4)])).toEqual([{ machine_id: "m", kind: "preventiva", a: 50, b: 75, diff: 25 }]);
  });
  it("período sem dados fica vazio", () => {
    expect(comparePeriods([], [g(1, 2)])[0]).toMatchObject({ a: null, b: 50, diff: null });
  });
  it("gera uma linha por item no CSV", () => {
    const csv = checklistCsv([g(1, 2)], new Map([["m", "Prensa"]]));
    expect(csv.split("\n")[1]).toBe('"Prensa";"preventiva";"50";"Óleo";"1";"2";"50";"sim"');
  });
});

import { filterParts, partsCost } from "./machines";
describe("peças", () => {
  const p = (o: object) => ({ name: "Rolamento", supplier: "", notes: "", machine_id: "a", status: "quebrada", created_at: "2026-10-10T12:00:00Z", ...o });
  const ps = [p({}), p({ name: "Correia", supplier: "Gates", status: "comprar", machine_id: "b", created_at: "2026-10-20T12:00:00Z" })];
  it("busca por nome ou fornecedor sem acento", () => {
    expect(filterParts(ps, { term: "gates" })).toEqual([ps[1]]);
  });
  it("filtra por máquina, situação e data", () => {
    expect(filterParts(ps, { machineId: "a", status: "quebrada", from: "2026-10-10", to: "2026-10-10" })).toEqual([ps[0]]);
  });
  it("custo = quantidade × preço unitário", () => {
    expect(partsCost([{ quantity: 3, unit_price: 25.5 }, { quantity: 2, unit_price: null }])).toBe(76.5);
  });
});
