import { supabase } from "@/integrations/supabase/client";
import { parseChecklist, parsePhotos, type Machine, type MaintenanceRecord } from "@/lib/machines";

async function toJpeg(url: string) {
  const img = new Image();
  img.crossOrigin = "anonymous";
  img.src = url;
  await img.decode();
  const max = 900, s = Math.min(1, max / Math.max(img.naturalWidth, img.naturalHeight));
  const c = document.createElement("canvas");
  c.width = img.naturalWidth * s; c.height = img.naturalHeight * s;
  c.getContext("2d")!.drawImage(img, 0, 0, c.width, c.height);
  return { data: c.toDataURL("image/jpeg", 0.85), w: c.width, h: c.height };
}

/** Builds the PDF report of one completed maintenance and downloads it. */
export async function downloadMaintenanceReport(machine: Machine, r: MaintenanceRecord) {
  const { jsPDF } = await import("jspdf");
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = 210, M = 15;
  let y = M;
  const need = (h: number) => { if (y + h > 297 - M) { doc.addPage(); y = M; } };
  const text = (t: string, size = 10, bold = false) => {
    doc.setFont("helvetica", bold ? "bold" : "normal").setFontSize(size);
    const lines = doc.splitTextToSize(t, W - 2 * M) as string[];
    need(lines.length * size * 0.45);
    doc.text(lines, M, y + size * 0.35);
    y += lines.length * size * 0.45 + 1.5;
  };
  const section = (t: string) => { y += 3; text(t.toUpperCase(), 9, true); doc.setDrawColor(200).line(M, y - 1, W - M, y - 1); y += 1; };
  const date = new Date(r.performed_at + "T00:00").toLocaleDateString("pt-BR");

  text("MaqSense — Relatório de manutenção", 16, true);
  text(`${machine.name}${machine.model ? " · " + machine.model : ""}${machine.serial_number ? " · Nº " + machine.serial_number : ""}`, 11);
  section("Dados do serviço");
  text(`Data: ${date}`);
  text(`Tipo: ${r.kind}`);
  text(`Responsável: ${r.technician || "Não informado"}`);
  if (r.downtime_hours != null) text(`Tempo parado: ${Number(r.downtime_hours).toLocaleString("pt-BR")} h`);
  if (r.cost != null) text(`Custo: R$ ${Number(r.cost).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}`);
  section("Observações");
  text(r.description || "Sem observações.");
  section("Peças utilizadas");
  text(r.parts_used || "Nenhuma peça informada.");

  const cl = parseChecklist(r.checklist);
  section(`Checklist (${cl.filter((c) => c.checked).length}/${cl.length})`);
  if (!cl.length) text("Sem checklist neste serviço.");
  cl.forEach((c) => text(`[${c.checked ? "X" : "  "}] ${c.item}${c.checked ? "" : "  (não verificado)"}`));

  const photos = parsePhotos(r.photos);
  if (photos.length) {
    const { data } = await supabase.storage.from("maintenance-photos").createSignedUrls(photos.map((p) => p.path), 600);
    for (const phase of ["antes", "depois"] as const) {
      const ps = photos.filter((p) => p.phase === phase);
      if (!ps.length) continue;
      section(`Fotos ${phase}`);
      let x = M; const boxW = (W - 2 * M - 5) / 2, boxH = 60;
      for (const p of ps) {
        const url = data?.find((d) => d.path === p.path)?.signedUrl;
        if (!url) continue;
        try {
          const img = await toJpeg(url);
          const s = Math.min(boxW / img.w, boxH / img.h);
          if (x === M) need(boxH + 3);
          doc.addImage(img.data, "JPEG", x, y, img.w * s, img.h * s);
          if (x === M) x = M + boxW + 5; else { x = M; y += boxH + 3; }
        } catch { /* skip unreadable image */ }
      }
      if (x !== M) y += boxH + 3;
    }
  }

  doc.setFontSize(8).setTextColor(130).text(`Gerado em ${new Date().toLocaleString("pt-BR")}`, M, 297 - 8);
  doc.save(`manutencao-${machine.name.replace(/[^\w-]+/g, "_")}-${r.performed_at}.pdf`);
}
