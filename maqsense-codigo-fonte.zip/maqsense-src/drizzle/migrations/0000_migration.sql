CREATE TABLE public.machines (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  name text NOT NULL,
  manufacturer text NOT NULL DEFAULT '',
  model text NOT NULL DEFAULT '',
  serial_number text NOT NULL DEFAULT '',
  category text NOT NULL DEFAULT '',
  location text NOT NULL DEFAULT '',
  installed_at date,
  status text NOT NULL DEFAULT 'ok',
  specs jsonb NOT NULL DEFAULT '[]'::jsonb,
  notes text NOT NULL DEFAULT '',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.machines TO authenticated;
GRANT ALL ON public.machines TO service_role;
ALTER TABLE public.machines ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own machines all" ON public.machines FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.maintenance_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  machine_id uuid NOT NULL REFERENCES public.machines(id) ON DELETE CASCADE,
  performed_at date NOT NULL DEFAULT current_date,
  kind text NOT NULL DEFAULT 'preventiva',
  technician text NOT NULL DEFAULT '',
  description text NOT NULL DEFAULT '',
  cost numeric,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.maintenance_records TO authenticated;
GRANT ALL ON public.maintenance_records TO service_role;
ALTER TABLE public.maintenance_records ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own maint all" ON public.maintenance_records FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE TABLE public.manuals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  machine_id uuid NOT NULL REFERENCES public.machines(id) ON DELETE CASCADE,
  title text NOT NULL,
  url text,
  file_path text,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.manuals TO authenticated;
GRANT ALL ON public.manuals TO service_role;
ALTER TABLE public.manuals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own manuals all" ON public.manuals FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "manuals read own" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'manuals' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "manuals insert own" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'manuals' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "manuals delete own" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'manuals' AND (storage.foldername(name))[1] = auth.uid()::text);