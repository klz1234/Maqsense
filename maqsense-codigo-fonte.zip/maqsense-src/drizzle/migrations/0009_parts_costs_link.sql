ALTER TABLE public.parts ADD COLUMN supplier text NOT NULL DEFAULT '';
ALTER TABLE public.parts ADD COLUMN unit_price numeric;
ALTER TABLE public.parts ADD COLUMN purchased_at date;
ALTER TABLE public.parts ADD COLUMN maintenance_id uuid REFERENCES public.maintenance_records(id) ON DELETE SET NULL;