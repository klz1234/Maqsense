ALTER TABLE public.maintenance_records ADD COLUMN photos jsonb NOT NULL DEFAULT '[]'::jsonb;
ALTER TABLE public.maintenance_records ADD COLUMN checklist jsonb NOT NULL DEFAULT '[]'::jsonb;

CREATE TABLE public.checklist_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  kind text NOT NULL,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, kind)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.checklist_templates TO authenticated;
GRANT ALL ON public.checklist_templates TO service_role;
ALTER TABLE public.checklist_templates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own templates all" ON public.checklist_templates FOR ALL TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

CREATE POLICY "own maint photos select" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'maintenance-photos' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "own maint photos insert" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'maintenance-photos' AND (storage.foldername(name))[1] = auth.uid()::text);
CREATE POLICY "own maint photos delete" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'maintenance-photos' AND (storage.foldername(name))[1] = auth.uid()::text);