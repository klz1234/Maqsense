ALTER TABLE public.machines ADD COLUMN maintenance_interval_days integer;
ALTER TABLE public.maintenance_records ADD COLUMN parts_used text NOT NULL DEFAULT '';