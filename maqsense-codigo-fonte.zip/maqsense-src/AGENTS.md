<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Data access uses the browser Supabase client with RLS scoped to user_id; queries live in src/lib/machines.ts as queryOptions (single source for cache keys).
- Manual PDFs go in the private `manuals` bucket under `<user_id>/<machine_id>/`, opened via signed URLs (storage RLS checks the first folder).
